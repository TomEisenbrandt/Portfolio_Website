﻿
//	NAME:       Tom Eisenbrandt
//	ZID:        Z1771209
//	CLASS:      CSCI 473
//	SECTION:    01
//	TEACHER:    Harry Hutchins
//	DUE DATE:   February 2nd 2018
//	Project:	01

using System ;
using System.IO ;
using System.Collections ;
using System.Collections.Generic ;
using System.Linq ;
using System.Text ;
using System.Threading.Tasks ;

//	Namespace Assign1
namespace Assign1 {
//
//-----------------------------------------------------------------------------------------------//
//  *   *   *   *   *	Class: Person	*	*	*	*	*
//	The declaration for Person should mention the IComparable interface.
public class Person : IComparable {
//
private string NAME = null ;        //  Private data member NAME
private string OFFICE = null ;      //  Private data member OFFICE
private string PHONE = null ;       //  Private data member PHONE
//
//  Constructor with three string values
public Person( string name , string office , string phone ) {
NAME = name ;
OFFICE = office ;
PHONE = phone ;			
}   //  End of constructor
//
//
public string Name  {   //	Public Properties for Name
get{ return NAME ;  }   //  >
set{ NAME = value ; }   //  >
}
//
public string Office  { //  Public properties for Office
get{ return OFFICE ;  } //  >
set{ OFFICE = value ; } //  >
}
//
public string Phone  {  //  Public properties for Phone
get{ return PHONE ;  }  //  >
set{ PHONE = value ; }  //  >
}
//
public int CompareTo( object OBJ ) {    //  Compares the current instance with the passed in value
Person n = ( Person )OBJ ;
if( this == OBJ ) { 
return 0 ;
}
//else if( this > OBJ ) {
//return 1 ;
//}
else{ 
return -1 ;
}
}
//
}   // End of Class: Person 
//
//-----------------------------------------------------------------------------------------------//
//  *   *   *   *   *	Class: Program	*	*	*	*	*
class Program {
//	Public static (jagged)array initialized to 20 rows and 3 columns
//  [ n ][ 0 ] = Name , [ n ][ 1 ] = Office Number , [ n ][ 2 ] = Phone Number
public static string[ ][ ] Person = new string[ 20 ][  ] ;
//	Public static integer InUse Initialized to 0.
public static int InUse = 0 ;
//
//-----------------------------------------------------------------------------------------------//
//  *   *   *   *   *	Main	*	*	*	*	*
static void Main( string[ ] args ) {
//
bool LOOP = true ;                  //  Boolean used for looping program( true = loop / false = exit )
string MenuInput = null ;           //  String that holds user input
string LINE ;                       //  Streams file I/O
string FILE_NAME = "data1.txt" ;    //  String of input file.
string q = "0" ;                    //  Default string value
//
for( int i = 0 ; i < Person.Length ; i++ ) {    //  Initialize the entire array to a default string value 
Person[ i ] = new string[ 3 ] { q , q , q } ;
}   //  End of for
//
StreamReader sr = new StreamReader( FILE_NAME ) ; //  Pass file to stream
//
for( int i = 0 ; i <= Person.Length ; i++  ) {   //  Read file in via for-loop
//
LINE = sr.ReadLine( ) ; //  Stream in name data
//
if( LINE == null ) {    //  Checks to make sure only valid input is streamed
break ;                 //  Exits loop if invalid/lack of data detected
}   //  End if
//
Person[ i ][ 0 ] = LINE ;   //  Write stream data to name
//
LINE = sr.ReadLine( ) ;     //  Stream in office data
Person[ i ][ 1 ] = LINE ;   //  Write stream data to office  
//
LINE = sr.ReadLine( ) ;     //  Stream in phone data
Person[ i ][ 2 ] = LINE ;   //  Write stream data to phone
//
InUse = i ;   //  Increment count by 1
}   //  End for-loop
//
do {    //  Begin do-while loop for menu
Console.WriteLine( "A : Print Personal List" ) ;        //  Display menu options to user
Console.WriteLine( "B : Add Entry To List" ) ;          //  >
Console.WriteLine( "C : Search By Name" ) ;             //  >
Console.WriteLine( "D : Search By Office Number" ) ;    //  >
Console.WriteLine( "E : Search By Telephone Number" ) ; //  >
Console.WriteLine( "F : Change An Office Number" ) ;    //  >
Console.WriteLine( "G : Sort The List By Name" ) ;      //  >
Console.WriteLine( "H : Exit" ) ;                       //  >
//
MenuInput = Console.ReadLine( ) ;   // Read user input into MenuInput
MenuInput = MenuInput.ToUpper( ) ;  //	Convert contents of MenuInput to uppercase (a,b,c,...) -> (A,B,C,...)
//
switch( MenuInput ) {   //  Switch
//
//*************************************************************************************************//
//
case "A":   //	Option A/a : Print the list
//
Console.WriteLine( "Name      Office    Phone" ) ;      //  Print titles at top of list
//
for ( int i = 0 ; i <= InUse ; i++ ) {                  //  Printing loop
Console.Write( Person[ i ][ 0 ].PadRight( 10 ) ) ;      //  Print name
Console.Write( Person[ i ][ 1 ].PadRight( 10 ) ) ;      //  Print office
Console.WriteLine( Person[ i ][ 2 ].PadRight( 10 ) ) ;  //  Print phone
}   //  End of for loop
Console.WriteLine( "Name      Office    Phone" ) ;      //  Print titles at bottom of list
break ;
//
//*************************************************************************************************//
//
case "B":   //  Option B/b : Add an entry	
//
string NameAdd ;    //  Input for new name
string OfficeAdd ;  //  Input for new office number
string PhoneAdd ;   //  Input for new phone number
//
InUse++ ;   //  Increment InUse by +1
//
Console.WriteLine( "Enter Name to add" ) ;  //  Prompt for name input
NameAdd = Console.ReadLine( ) ;             //  Enter name input
Person[ InUse ][ 0 ] = NameAdd ;            //  Add data to array
//
Console.WriteLine( "Enter Office Number to add" ) ; //  Prompt for office input
OfficeAdd = Console.ReadLine( ) ;                   //  Enter office input
Person[ InUse ][ 1 ] = OfficeAdd ;                  //  Add data to array
//
Console.WriteLine( "Enter Phone Number to add" ) ;  //  Prompt for phone input
PhoneAdd = Console.ReadLine( ) ;                    //  Enter phone input
Person[ InUse ][ 2 ] = PhoneAdd ;                   //  Add data to array
//
Console.WriteLine( "New entry added. Returning to menu..." ) ;  //  If match not found print error message
break ;
//
//*************************************************************************************************//
//
case "C":   //  Option C/c : Search for a name
//
string SearchName ;     //  Hold user name value
string CompareName ;    //  Holds current value being compared to user input
//
Console.WriteLine( "Enter Name to search." ) ;  //  Prompt user for name input
SearchName = Console.ReadLine( ) ;              //  Take in name input
//
for( int i = 0 ; i < Person.Length ; i++ ) {    //  Iterate through array 
CompareName = Person[ i ][ 0 ] ;                //  CompareName holds current array iteration
//
if( CompareName == SearchName ) {       //  Compare current iteration with user input
Console.Write( SearchName ) ;           //  If match found print out name, office and phone
Console.WriteLine( " found." ) ;        //  >
Console.Write( "Office: " ) ;           //  >
Console.WriteLine( Person[ i ][ 1 ] ) ; //  >
Console.Write( "Phone:  " ) ;           //  >
Console.WriteLine( Person[ i ][ 2 ] ) ; //  >
break ;                                 //  >
}   //  End of if
}   //  End of for
//
Console.WriteLine( "Name not found. Returning to menu..." ) ;   //  If match not found print error message
break ;
//
//*************************************************************************************************//
//
case "D":   //  Option D/d : Search for an Office Number
//
string SearchOffice ;
bool FoundOffice = false ;
int OfficerCounter = 0 ;
//
Console.WriteLine( "Enter Office to search." ) ;
SearchOffice = Console.ReadLine( ) ;
//
for( int i = 0 ; i < Person.Length ; i++ ) {
CompareName = Person[ i ][ 1 ] ;     
//
if( CompareName == SearchOffice ) { //  Compare input with current iteration
FoundOffice = true ;
OfficerCounter++ ;  //  Increment counter by 1
//
if( OfficerCounter == 1 ) {         //  If count equals one
Console.Write( SearchOffice ) ;     //  then display success message
Console.WriteLine( " found." ) ;    //  >
}   //  End of if
//
Console.Write( "Name(s):  " ) ;         //
Console.WriteLine( Person[ i ][ 0 ] ) ; //
Console.Write( "Phone(s): " ) ;         //
Console.WriteLine( Person[ i ][ 2 ] ) ; //
}   //  End of if
}   //  End of for
//
if( FoundOffice == true ) {
break ;               
}   //  End of if
else{ 
Console.WriteLine( "Office not found. Returning to menu..." ) ; //  Print error message
break ;
}   //  End of if-else
//
//*************************************************************************************************//
//
case "E":   //  Option E/e : Search for a Phone Number
//
string SearchPhone ;    //  User input
string ComparePhone ;   //  Input compared with iteration
//
Console.WriteLine( "Enter Phone Number to search." ) ;  //  Prompt user for phone data
SearchPhone = Console.ReadLine( ) ;                     //  User input phone data
//
for( int i = 0 ; i < Person.Length ; i++ ) {    //  Itterate through array
ComparePhone = Person[ i ][ 2 ] ;               //  Compare current itteration to input
//
if( ComparePhone == SearchPhone ) {     //  If iteration is equal to input
Console.Write( SearchPhone ) ;          //  >
Console.WriteLine( " found." ) ;        //  >
Console.Write( "Name:    " ) ;          //  >
Console.WriteLine( Person[ i ][ 0 ] ) ; //  >
Console.Write( "Office:  " ) ;          //  >
Console.WriteLine( Person[ i ][ 1 ] ) ; //  >
break ;                                 //  >
}   // End of if
}   //  End of for
//
Console.WriteLine( "Phone Number not found. Returning to menu..." ) ;   //  Error message
break ;
//
//*************************************************************************************************//
//
case "F":   //  Option F/f : Change an Office Number
//
bool Listed = false ;   //  False = failed search / true = success
string OfficeNum ;      //  Holds new office number
string OfficeOwner ;    //  Holds office owner
string CompareOwner ;   //  holds current iteration
//
Console.WriteLine( "Enter the owner of the office number to change." ) ;    //  Prompt user for office number
OfficeOwner = Console.ReadLine( ) ;                                         //  >
Console.WriteLine( "Enter the new office number." ) ;   //  Prompt user for new office number
OfficeNum = Console.ReadLine( ) ;                       //  >
//
for( int i = 0 ; i < Person.Length ; i++ ) {    //  Iterate through array 
CompareOwner = Person[ i ][ 0 ] ;               //  CompareName holds current array iteration
//
if( OfficeOwner == CompareOwner ) {     //  If name match is found
Person[ i ][ 1 ] = OfficeNum ;          //  Change the value of the Office number
Listed = true ;                         //  enable success exit
}   //  End of if
}   //  End of for
if( Listed == true ) {          
Console.WriteLine( "Office Number changed. Returning to menu..." ) ;    //  Success message
break ;
}   //  End of if
else{
Console.WriteLine( "Office not found. Returning to menu..." ) ;  //  Failure Message
break ;
}   //  End of if-else
//
//*************************************************************************************************//
//
case "G":   //  Option G/g : Sort the list by name
//
Array.Sort( Person ) ;
//Person.Sort( ) ;
//
break ;
//
//*************************************************************************************************//
//
case "H":       //	Option H/h : Quit
LOOP = false ;  //  Loop disabled
break ;         //  Break from switch ( and leave switch loop )
//
//*************************************************************************************************//
//
default:                                            //	Default option for invalid input
Console.WriteLine( "That was not a choice." ) ;     //  >
break ;                                             //  >
//
}   //  End of switch
//
} while ( LOOP == true ) ;  //  End of do-while loop
//
Console.WriteLine( "Press Enter to exit" ) ;    //	Prompt prevents window from closing abruptly
MenuInput = Console.ReadLine( ) ;               //  Input
//
}   //  End of Main
//
}   //  End of Program
//
}   //  End of Assign1





//  END OF FILE




