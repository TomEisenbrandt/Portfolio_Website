﻿/****************************
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 473
GROUP:      36
SECTION:    01
PROJECT:    03
DUE:        March 7th 2018 23:59:59
****************************/
//
/***************************************************************************************************************************************************/
//
using System ;
using System.IO ;
using System.Collections.Generic ;
using System.ComponentModel ;
using System.Data ;
using System.Drawing ;
using System.Linq ;
using System.Text ;
using System.Threading.Tasks ;
using System.Windows.Forms ;
using System.Data.SqlClient ;
using MySql.Data ;
using MySql.Data.MySqlClient ;
//
/***************************************************************************************************************************************************/
//
namespace Assign3 {
//
    public partial class Form1: Form {
    //      
        public Form1( ) {
        InitializeComponent( ) ;
        }
        //
/****************************
Form1_Load
This method will load in as the application starts
****************************/
        private void Form1_Load( object sender , EventArgs e ) {
        //
            string MyConString = "server=10.158.56.53;" +   //  MySQL Connection string
                                "uid=csci473g36;" +
                                "pwd=wordpass36;" +
                                "database=csci473g36;" ;
            using( MySqlConnection MyConnection = new MySqlConnection( MyConString ) ) {    //  using MySqlConnection
            try{    //  Open and test connection
            MyConnection.Open( ) ;
            }// End of try
            catch{
            OutputDisplay.Items.Add( item: "Error Opening initial connection" ) ;
            }// End of catch
            // 
/****************************
Drop tables if they exist( RESET TABLES )
****************************/
            //
            try{    //  Drop OfficeTable if it exists
            string OfficeDrop = "DROP TABLE IF EXISTS OfficeTable" ;
            MySqlCommand OfficeDropper = new MySqlCommand( OfficeDrop , MyConnection ) ;
            OfficeDropper.ExecuteNonQuery( ) ;
            }
            catch{
            OutputDisplay.Items.Add( item: "Exception: Office Table Drop" ) ;
            }
            //
            try{    //  Drop RoomTable if it exists
            string RoomDrop = "DROP TABLE IF EXISTS RoomTable" ;
            MySqlCommand RoomDropper = new MySqlCommand( RoomDrop , MyConnection ) ;
            RoomDropper.ExecuteNonQuery( ) ;
            }
            catch{
            OutputDisplay.Items.Add( item: "Exception: Room Table Drop" ) ;
            }
            //
            try{    //  Drop ClassTable if it exists
            string ClassDrop = "DROP TABLE IF EXISTS ClassTable" ;
            MySqlCommand ClassDropper = new MySqlCommand( ClassDrop , MyConnection ) ;
            ClassDropper.ExecuteNonQuery( ) ;
            }
            catch{
            OutputDisplay.Items.Add( item: "Exception: ClassTable Drop" ) ;
            }
            //
/****************************
Create OfficeTable - 2 Columns    
    Column 1: Teacher = Teacher name ( char[20] ) [ PRIMARY KEY ]
    Column 2: Office = Number of an office ( int )
****************************/
            bool OfficeTableExists ;
            try{
            MySqlCommand CreateOfficeTable = new MySqlCommand( "CREATE TABLE OfficeTable(Teacher char(20) NOT NULL, " +
                                                                                        "Office int NULL, " + 
                                                                                        "PRIMARY KEY (Teacher) )" , MyConnection ) ;
            OfficeTableExists = ( int )CreateOfficeTable.ExecuteNonQuery( ) == 1 ;    //  Execute command to make table for Office data
            }// End of try1 CreateOfficeTable
            catch{ 
                try{ 
                OfficeTableExists = true ;
                }// End of try2 CreateOfficeTable
                catch{
                OfficeTableExists = false ;
                }// End of catch2 CreateOfficeTable
            }// End of catch1 CreateOfficeTable
            //
/****************************
Create RoomTable - 3 Columns
    Comulm 1: Room = Room number ( int ) [ PRIMARY KEY ]
    Column 2: Capacity = Seating capacity of room ( int )
    Column 3: Smart = Flag for 'smart classroom' ( y = yes , n = no ) ( char[1] )
****************************/
            bool RoomTableExists ;
            try{ 
            MySqlCommand CreateRoomTable = new MySqlCommand( "CREATE TABLE RoomTable(Room int NOT NULL, " + 
                                                                                    "Capacity int NULL, " +
                                                                                    "Smart nchar(1) NULL, " + 
                                                                                    "PRIMARY KEY (Room) )" , MyConnection ) ;
            RoomTableExists = ( int )CreateRoomTable.ExecuteNonQuery( ) == 1 ;    //  Execute command to make table for Room data
            }// End of try1 CreateRoomTable
            catch{ 
                try{ 
                RoomTableExists = true ;
                }// End of try2 CreateRoomTable
                catch{
                RoomTableExists = false ;
                }// End of catch2 CreateRoomTable
            }// End of catch1 CreateRoomTable
            //
/****************************
Create ClassTable - 6 Columns
    Column 1: Class = Number of a class ( string ) [ PRIMARY KEY ]
    Column 2: Teacher = Name of teacher ( char[20(max)] ) [ FOREIGN KEY : RoomTable ]
    Column 3: Room = Room number ( int ) [ FOREIGN KEY : OfficeTable ]
    Column 4: Time = Time when class begins ( char[5] )
    Column 5: Days =  Which days class is held ( char[5(max)] )
    Column 6: Enrollment = Current enrollment of class ( int )
****************************/
/////////////////////////////////////////////////////////////////////////////////////////////////// ERROR
            bool ClassTableExists ;
            try{ 
            MySqlCommand CreateClassTable = new MySqlCommand( "CREATE TABLE ClassTable("   + 
                                                                "Class string NULL, "      +          
                                                                "Teacher nchar(20) NULL, " +      
                                                                "Room int NULL, "          +                
                                                                "Time nchar(5) NULL, "     +         
                                                                "Days nchar(5) NULL, "     +         
                                                                "Enrollment int NULL, "    +      
                                                                "PRIMARY KEY (Class), "    + 
                                                                "FOREIGN KEY (Teacher), "  + 
                                                                "FOREIGN KEY (Room) "      +
                                                                ") " , MyConnection ) ;
            ClassTableExists = ( int )CreateClassTable.ExecuteNonQuery( ) == 1 ;    //  Execute command to make table for Class data
            }// End of try1 CreateClassTable
            catch{ 
                try{ 
                ClassTableExists = true ;
                }// End of try2 CreateClassTable
                catch{
                ClassTableExists = false ;
                }// End of catch2 CreateClassTable
            }// End of catch1 CreateClassTable
            //
/****************************
Fill OfficeTable with contents of Office.txt via insert
****************************/
            string StreamLine = "" ;    //  holds stream value
            char SpiltDelimiter = ',' ; //  Spilt delimiter
            try{
            StreamReader sr = new StreamReader( "Office.txt" ) ;    //  Pass file to streamreader
            StreamLine = sr.ReadLine( ) ; //  Read first line
                while( StreamLine != null ) {  //  Loop read until end of file
                string [ ] OfficeParts = StreamLine.Split( SpiltDelimiter ) ;  //  Split the string that was read in
                //  Format string for command
                string OfficeInsert = String.Format( "INSERT INTO OfficeTable ( Teacher, Office ) " + 
                                                    " Values ( '{0}' , '{1}' )" , OfficeParts[ 0 ] , OfficeParts [ 1 ] ) ;
                    try{ 
                    MySqlCommand CommandOfficeInsert = new MySqlCommand( OfficeInsert , MyConnection ) ;   //  Insert Office values into table
                    CommandOfficeInsert.ExecuteNonQuery( ) ;    //  Execute command to insert Office data
                    }// End of try
                    catch{
                    OutputDisplay.Items.Add( item: "Exception: Office Value Insert " ) ;
                    }// End of catch
                StreamLine = sr.ReadLine( ) ; //  Read next line
                }// End of while
                //
            sr.Close( ) ;   //  Close file stream
            }// End of try
            catch{
            OutputDisplay.Items.Add( item: "Exception: OfficeTable StreamReader " ) ;
            }// End of catch
            //
/****************************
Fill RoomTable with contents of Room.txt via insert
****************************/
            try{
            string StreamLine2 = "" ;    //  holds stream value
            char SpiltDelimiter2 = ',' ; //  Spilt delimiter
            StreamReader sr = new StreamReader( "Room.txt" ) ;    //  Pass file to streamreader
            StreamLine2 = sr.ReadLine( ) ; //  Read first line
                while( StreamLine2 != null ){  //  Loop read until end of file
                string [ ] RoomParts = StreamLine2.Split( SpiltDelimiter2 ) ;  //  Split the string that was read in
                //  Format string for command
                string RoomInsert = String.Format( "INSERT INTO RoomTable ( Room , Capacity , Smart ) " + 
                                                    " Values ( '{0}' , '{1}' , '{2}' )" , RoomParts[ 0 ] , RoomParts[ 1 ] , RoomParts[ 2 ] ) ;
                    try{ 
                    MySqlCommand CommandRoomInsert = new MySqlCommand( RoomInsert , MyConnection ) ;   //  Insert Room values into table
                    CommandRoomInsert.ExecuteNonQuery( ) ;  //  Insert Room values into table
                    }// End of try
                    catch{
                    OutputDisplay.Items.Add( item: "Exception: CommandRoomInsert " ) ;
                    }// End of catch
                StreamLine2 = sr.ReadLine( ) ; //  Read next line
                }// End of while
                //
            sr.Close( ) ;   //  Close file stream
            }// End of try
            catch{
            OutputDisplay.Items.Add( item: "Exception: RoomTable Insert " ) ;
            }// End of catch
            //
/****************************
Fill ClassTable with contents of Class.txt via insert
****************************/
/////////////////////////////////////////////////////////////////////////////////////////////////// ERROR

/////////////////////////////////////////////////////////////////////////////////////////////////// This section of code will provide exception errors due to the error in Create ClassTable
            try {
            string StreamLine3 = "" ;    //  holds stream value
            char SpiltDelimiter3 = ',' ; //  Spilt delimiter
            StreamReader sr = new StreamReader( "Class.txt" ) ;    //  Pass file to streamreader
            StreamLine3 = sr.ReadLine( ) ; //  Read first line
                while( StreamLine3 != null ) {  //  Loop read until end of file
                string [ ] ClassParts = StreamLine3.Split( SpiltDelimiter3 ) ;  //  Split the string that was read in
                //  Format string for command
                string ClassInsert = String.Format( "INSERT INTO ClassTable ( Class , Teacher , Room , Time , Days , Enrollment ) " + 
                                                    " Values ( '{0}' , '{1}' , '{2}' , '{3}' , '{4}' , '{5}' " + 
                                                    ")" , ClassParts[ 0 ] , ClassParts[ 1 ] , ClassParts[ 2 ] , ClassParts[ 3 ] , ClassParts[ 4 ] , ClassParts[ 5 ] ) ;
                    try{ 
                    MySqlCommand CommandClassInsert = new MySqlCommand( ClassInsert , MyConnection ) ; //  Insert Class values into table
                    CommandClassInsert.ExecuteNonQuery( ) ;  //  Insert Class values into table
                    }// End of try
                    catch{
                    OutputDisplay.Items.Add( item: "Error: ClassTable insert failed " ) ;
                    }// End of catch
                StreamLine3 = sr.ReadLine( ) ; //  Read next line
                }// End of while
                //
            sr.Close( ) ;   //  Close file stream
            }// End of try
            catch{
            OutputDisplay.Items.Add( item: "Exception: ClassTable Insert " ) ;
            }// End of catch
            //
/****************************
Get schema from the three tables
Print the names of the three tables
****************************/            
            try{ 
            DataTable TableSchema = MyConnection.GetSchema( "Tables" ) ; // Get table name schema
            List< string > TableNames = new List< string >( ) ;
            OutputDisplay.Items.Add( item: "List of tables: " ) ; // Display table
                foreach( DataRow row in TableSchema.Rows ){
                OutputDisplay.Items.Add( item: row[ 2 ].ToString( ) ) ;
                }// End foreach
                //
            }// End try
            catch{ 
            OutputDisplay.Items.Add( item: "Error: Table Schema " ) ; // catch output
            }// End catch
            //
            MyConnection.Close( ) ; //  Close Connection
            }// End of using (MySqlConnection)
        //
        OutputDisplay.Items.Add( item: "Enter a SQL query" ) ; //  DEBUG
        }// End of Form1_Load
        //
//
/***************************************************************************************************************************************************/
//
/****************************
EnterButton
Clicking button will enter the user input for an SQL query
valid input will start with 'SELECT COUNT' , 'SELECT' or 'INSERT'
****************************/
        private void EnterButton_Click( object sender , EventArgs e ) {
        string INPUT = " " ;
        String [ ] InputParts = new string [ 20 ] ; //  Max command size = 20 words
        int Switcher = 0 ;
        INPUT = InputLine.Text.ToLower() ;    //  Store user input
        InputParts[ 0 ] = "sauce" ; //  Give value, avoid range exception
        InputParts[ 1 ] = "sauce" ; //  Give value, avoid range exception
        InputParts = INPUT.Split( null ) ; //  split user input into parts via a delimiter of whitespace ' '
            for( int i = 0 ; i < InputParts.Length ; i++ ) {  //  correct input values after ToLower formatted
            //    
                if( Equals( "officetable" , InputParts[ i ] ) ){
                InputParts[ i ] = "OfficeTable" ;
                }// End of if roomtable
                //
                if( Equals( "roomtable" , InputParts[ i ] ) ){
                InputParts[ i ] = "RoomTable" ;
                }// End of if roomtable
                //
                if( Equals( "Classtable" , InputParts[ i ] ) ){
                InputParts[ i ] = "ClassTable" ;
                }// End of if roomtable
                //
            }// End of for
            //
        OutputDisplay.Items.Add( INPUT ) ;  //  Show user input
        string ConString = "server=10.158.56.53;" + //  MySQL Connection string
                            "uid=csci473g36;" +
                            "pwd=wordpass36;" +
                            "database=csci473g36;" ;
            using( MySqlConnection MyConn = new MySqlConnection( ConString ) ) {    //  using MySqlConnection
                try{    //  Open and test connection
                MyConn.Open( ) ;
                }// End of try
                catch{
                OutputDisplay.Items.Add( item: "Connection Error!" ) ;
                }// End of catch
                //
                try{
                    if( Equals( "select" , InputParts[ 0 ] ) && Equals( "count" , InputParts[ 1 ] ) ) {
                    Switcher = 1 ;    
                    }// End of if "select count"
                    //
                    else if( Equals( "select" , InputParts[ 0 ] ) ) { 
                    Switcher = 2 ;    
                    }// End of if "select"
                    //
                    else if( Equals( "insert" , InputParts[ 0 ] ) ) { 
                    Switcher = 3 ; 
                    }// End of if "insert"
                    //
                }
                catch{
                OutputDisplay.Items.Add( item: "Invalid Input!" ) ;
                }
                //
                switch( Switcher ) {
/*************************************************************************************************/
                    case 1: //  If input starts with "select count"
                    try{
                    int IntResult = 0 ;
                    string RESULT = "" ;
/////////////////////////////////////////////////////////////////////////////////////////////////// ERROR
                    MySqlCommand SelectCountCommand = new MySqlCommand( INPUT , MyConn ) ; //  Create the command for select count
                    IntResult = ( int )SelectCountCommand.ExecuteScalar( ) ;    //  Execute command
                    RESULT = String.Format( "Count:" + IntResult ) ;    //  Format output
                    OutputDisplay.Items.Add( item: RESULT ) ;
                    }// End of try
                    catch{ 
                    OutputDisplay.Items.Add( item: "Count Error!" ) ;
                    }// End of catch
                    break ;//   End of case 1
/*************************************************************************************************/
                    case 2: //  If input starts with "select"
                    MySqlCommand SelectCommand = new MySqlCommand( INPUT , MyConn ) ; //  Create the command for select count
                        try{     
/////////////////////////////////////////////////////////////////////////////////////////////////// ERROR
                        MySqlDataReader MyReader = SelectCommand.ExecuteReader( ) ;
                            while( MyReader.Read( ) ) { 
                            OutputDisplay.Items.Add( item: MyReader ) ;  //  Output
                            }// End of while
                        MyReader.Close( ) ; //  Close the reader 
                        }// End of try
                        catch{
                        OutputDisplay.Items.Add( item: "Read Error!" ) ;
                        }// End of catch 
                    break ;//   End of case 2
/*************************************************************************************************/
                    case 3: //  If input starts with "insert"
                    OutputDisplay.Items.Add( item: "Non Query Command used." ) ;
                    try{
/////////////////////////////////////////////////////////////////////////////////////////////////// ERROR
                    MySqlCommand InsertCommand = new MySqlCommand( INPUT , MyConn ) ;
                    InsertCommand.ExecuteNonQuery( ) ;
                    OutputDisplay.Items.Add( item: "Insert Complete." ) ;
                    }
                    catch{
                    OutputDisplay.Items.Add( item: "Insert Error!" ) ;
                    }// End of catch
                    break ;//   End of case 3
                    /*****/
                    default:
                    OutputDisplay.Items.Add( item: "That command is not implmented or has bad syntax." ) ;  //  Error message
                    break ;//   End of switch default                 
                }// End of switch
                //
            MyConn.Close( ) ; //  Close Connection
            }// End of using MyConn
            //
        OutputDisplay.Items.Add( item: " " ) ;  //  Print new blank line after query for spacing
        }// End of enter button
//
/***************************************************************************************************************************************************/
//
/****************************
ClearButton
clicking button clears any user input in the text box(InputLine) 
and clears the output log in the listbox(OutputDisplay)
****************************/
        private void ClearButton_Click( object sender , EventArgs e ) {
        InputLine.Clear( ) ;    //  Clear the text input box
        OutputDisplay.Items.Clear( ) ;  //  Clear the listbox
        }// End of clear button method
        //
//
/***************************************************************************************************************************************************/
//
/****************************
ExitButton
Clicking button will exit application
****************************/
        private void ExitButton_Click( object sender , EventArgs e ) {
        Application.Exit( ) ;   //  Exit program
        }// End of exit button method
        //
    }// End of class
    //
}// End of namespace
//
/*
    END OF FILE
*/
///////////////////////////////////////////////////////////////////////////////////////////////////

