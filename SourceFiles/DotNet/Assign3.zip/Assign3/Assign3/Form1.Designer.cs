﻿namespace Assign3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputLine = new System.Windows.Forms.TextBox();
            this.InputLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.EnterButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.OutputDisplay = new System.Windows.Forms.ListBox();
            this.InputGroup = new System.Windows.Forms.GroupBox();
            this.InputGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // InputLine
            // 
            this.InputLine.Location = new System.Drawing.Point(99, 20);
            this.InputLine.Margin = new System.Windows.Forms.Padding(4);
            this.InputLine.Name = "InputLine";
            this.InputLine.Size = new System.Drawing.Size(640, 26);
            this.InputLine.TabIndex = 0;
            // 
            // InputLabel
            // 
            this.InputLabel.AutoSize = true;
            this.InputLabel.Location = new System.Drawing.Point(8, 23);
            this.InputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.InputLabel.Name = "InputLabel";
            this.InputLabel.Size = new System.Drawing.Size(83, 19);
            this.InputLabel.TabIndex = 1;
            this.InputLabel.Text = "SQL Query:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Department Data";
            // 
            // EnterButton
            // 
            this.EnterButton.Location = new System.Drawing.Point(99, 89);
            this.EnterButton.Margin = new System.Windows.Forms.Padding(4);
            this.EnterButton.Name = "EnterButton";
            this.EnterButton.Size = new System.Drawing.Size(135, 59);
            this.EnterButton.TabIndex = 3;
            this.EnterButton.Text = "Enter";
            this.EnterButton.UseVisualStyleBackColor = true;
            this.EnterButton.Click += new System.EventHandler(this.EnterButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(348, 89);
            this.ClearButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(135, 59);
            this.ClearButton.TabIndex = 4;
            this.ClearButton.Text = "Clear All";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(604, 89);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(135, 59);
            this.ExitButton.TabIndex = 5;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // OutputDisplay
            // 
            this.OutputDisplay.BackColor = System.Drawing.Color.Azure;
            this.OutputDisplay.FormattingEnabled = true;
            this.OutputDisplay.ItemHeight = 19;
            this.OutputDisplay.Location = new System.Drawing.Point(13, 223);
            this.OutputDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.OutputDisplay.Name = "OutputDisplay";
            this.OutputDisplay.Size = new System.Drawing.Size(818, 384);
            this.OutputDisplay.TabIndex = 6;
            // 
            // InputGroup
            // 
            this.InputGroup.Controls.Add(this.EnterButton);
            this.InputGroup.Controls.Add(this.ClearButton);
            this.InputGroup.Controls.Add(this.ExitButton);
            this.InputGroup.Controls.Add(this.InputLine);
            this.InputGroup.Controls.Add(this.InputLabel);
            this.InputGroup.Location = new System.Drawing.Point(13, 32);
            this.InputGroup.Margin = new System.Windows.Forms.Padding(4);
            this.InputGroup.Name = "InputGroup";
            this.InputGroup.Padding = new System.Windows.Forms.Padding(4);
            this.InputGroup.Size = new System.Drawing.Size(818, 174);
            this.InputGroup.TabIndex = 7;
            this.InputGroup.TabStop = false;
            this.InputGroup.Text = "Input";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(854, 644);
            this.Controls.Add(this.InputGroup);
            this.Controls.Add(this.OutputDisplay);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Assign 03";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.InputGroup.ResumeLayout(false);
            this.InputGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox InputLine;
        private System.Windows.Forms.Label InputLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button EnterButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.ListBox OutputDisplay;
        private System.Windows.Forms.GroupBox InputGroup;
    }
}

