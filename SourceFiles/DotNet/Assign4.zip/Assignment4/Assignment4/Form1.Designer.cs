﻿namespace Assignment4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint1 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 1D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint2 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 2D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint3 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 3D);
            this.TextInput = new System.Windows.Forms.TextBox();
            this.RadioGroup = new System.Windows.Forms.GroupBox();
            this.RadioChart = new System.Windows.Forms.RadioButton();
            this.RadioPie = new System.Windows.Forms.RadioButton();
            this.RadioColumn = new System.Windows.Forms.RadioButton();
            this.RadioBar = new System.Windows.Forms.RadioButton();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ChooseFileButton = new System.Windows.Forms.Button();
            this.FileValButton = new System.Windows.Forms.Button();
            this.RandValButton = new System.Windows.Forms.Button();
            this.UserValButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.InputGroup = new System.Windows.Forms.GroupBox();
            this.Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.RadioGroup.SuspendLayout();
            this.InputGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).BeginInit();
            this.SuspendLayout();
            // 
            // TextInput
            // 
            this.TextInput.Location = new System.Drawing.Point(89, 20);
            this.TextInput.Margin = new System.Windows.Forms.Padding(4);
            this.TextInput.Name = "TextInput";
            this.TextInput.Size = new System.Drawing.Size(461, 26);
            this.TextInput.TabIndex = 0;
            // 
            // RadioGroup
            // 
            this.RadioGroup.Controls.Add(this.RadioChart);
            this.RadioGroup.Controls.Add(this.RadioPie);
            this.RadioGroup.Controls.Add(this.RadioColumn);
            this.RadioGroup.Controls.Add(this.RadioBar);
            this.RadioGroup.Location = new System.Drawing.Point(13, 10);
            this.RadioGroup.Margin = new System.Windows.Forms.Padding(4);
            this.RadioGroup.Name = "RadioGroup";
            this.RadioGroup.Padding = new System.Windows.Forms.Padding(4);
            this.RadioGroup.Size = new System.Drawing.Size(131, 177);
            this.RadioGroup.TabIndex = 1;
            this.RadioGroup.TabStop = false;
            this.RadioGroup.Text = "RadioGroup";
            // 
            // RadioChart
            // 
            this.RadioChart.AutoSize = true;
            this.RadioChart.Location = new System.Drawing.Point(8, 117);
            this.RadioChart.Margin = new System.Windows.Forms.Padding(4);
            this.RadioChart.Name = "RadioChart";
            this.RadioChart.Size = new System.Drawing.Size(85, 23);
            this.RadioChart.TabIndex = 7;
            this.RadioChart.TabStop = true;
            this.RadioChart.Text = "Doughnut";
            this.RadioChart.UseVisualStyleBackColor = true;
            this.RadioChart.CheckedChanged += new System.EventHandler(this.RadioChart_CheckedChanged);
            // 
            // RadioPie
            // 
            this.RadioPie.AutoSize = true;
            this.RadioPie.Location = new System.Drawing.Point(8, 86);
            this.RadioPie.Margin = new System.Windows.Forms.Padding(4);
            this.RadioPie.Name = "RadioPie";
            this.RadioPie.Size = new System.Drawing.Size(46, 23);
            this.RadioPie.TabIndex = 6;
            this.RadioPie.TabStop = true;
            this.RadioPie.Text = "Pie";
            this.RadioPie.UseVisualStyleBackColor = true;
            this.RadioPie.CheckedChanged += new System.EventHandler(this.RadioPie_CheckedChanged);
            // 
            // RadioColumn
            // 
            this.RadioColumn.AutoSize = true;
            this.RadioColumn.Location = new System.Drawing.Point(8, 53);
            this.RadioColumn.Margin = new System.Windows.Forms.Padding(4);
            this.RadioColumn.Name = "RadioColumn";
            this.RadioColumn.Size = new System.Drawing.Size(74, 23);
            this.RadioColumn.TabIndex = 5;
            this.RadioColumn.TabStop = true;
            this.RadioColumn.Text = "Column";
            this.RadioColumn.UseVisualStyleBackColor = true;
            this.RadioColumn.CheckedChanged += new System.EventHandler(this.RadioColumn_CheckedChanged);
            // 
            // RadioBar
            // 
            this.RadioBar.AutoSize = true;
            this.RadioBar.Location = new System.Drawing.Point(8, 22);
            this.RadioBar.Margin = new System.Windows.Forms.Padding(4);
            this.RadioBar.Name = "RadioBar";
            this.RadioBar.Size = new System.Drawing.Size(49, 23);
            this.RadioBar.TabIndex = 4;
            this.RadioBar.TabStop = true;
            this.RadioBar.Text = "Bar";
            this.RadioBar.UseVisualStyleBackColor = true;
            this.RadioBar.CheckedChanged += new System.EventHandler(this.RadioBar_CheckedChanged);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(12, 62);
            this.ClearButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(150, 44);
            this.ClearButton.TabIndex = 2;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(12, 114);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(150, 44);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ChooseFileButton
            // 
            this.ChooseFileButton.Location = new System.Drawing.Point(208, 114);
            this.ChooseFileButton.Margin = new System.Windows.Forms.Padding(4);
            this.ChooseFileButton.Name = "ChooseFileButton";
            this.ChooseFileButton.Size = new System.Drawing.Size(150, 44);
            this.ChooseFileButton.TabIndex = 4;
            this.ChooseFileButton.Text = "Choose a file";
            this.ChooseFileButton.UseVisualStyleBackColor = true;
            this.ChooseFileButton.Click += new System.EventHandler(this.ChooseFileButton_Click);
            // 
            // FileValButton
            // 
            this.FileValButton.Location = new System.Drawing.Point(208, 62);
            this.FileValButton.Margin = new System.Windows.Forms.Padding(4);
            this.FileValButton.Name = "FileValButton";
            this.FileValButton.Size = new System.Drawing.Size(150, 44);
            this.FileValButton.TabIndex = 5;
            this.FileValButton.Text = "Value from File";
            this.FileValButton.UseVisualStyleBackColor = true;
            this.FileValButton.Click += new System.EventHandler(this.FileValButton_Click);
            // 
            // RandValButton
            // 
            this.RandValButton.Location = new System.Drawing.Point(400, 114);
            this.RandValButton.Margin = new System.Windows.Forms.Padding(4);
            this.RandValButton.Name = "RandValButton";
            this.RandValButton.Size = new System.Drawing.Size(150, 44);
            this.RandValButton.TabIndex = 6;
            this.RandValButton.Text = "Value at Random";
            this.RandValButton.UseVisualStyleBackColor = true;
            this.RandValButton.Click += new System.EventHandler(this.RandValButton_Click);
            // 
            // UserValButton
            // 
            this.UserValButton.Location = new System.Drawing.Point(400, 62);
            this.UserValButton.Margin = new System.Windows.Forms.Padding(4);
            this.UserValButton.Name = "UserValButton";
            this.UserValButton.Size = new System.Drawing.Size(150, 44);
            this.UserValButton.TabIndex = 7;
            this.UserValButton.Text = "Value from User";
            this.UserValButton.UseVisualStyleBackColor = true;
            this.UserValButton.Click += new System.EventHandler(this.UserValButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 23);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "User Input";
            // 
            // InputGroup
            // 
            this.InputGroup.Controls.Add(this.TextInput);
            this.InputGroup.Controls.Add(this.UserValButton);
            this.InputGroup.Controls.Add(this.label5);
            this.InputGroup.Controls.Add(this.ExitButton);
            this.InputGroup.Controls.Add(this.FileValButton);
            this.InputGroup.Controls.Add(this.RandValButton);
            this.InputGroup.Controls.Add(this.ClearButton);
            this.InputGroup.Controls.Add(this.ChooseFileButton);
            this.InputGroup.Location = new System.Drawing.Point(152, 13);
            this.InputGroup.Margin = new System.Windows.Forms.Padding(4);
            this.InputGroup.Name = "InputGroup";
            this.InputGroup.Padding = new System.Windows.Forms.Padding(4);
            this.InputGroup.Size = new System.Drawing.Size(558, 174);
            this.InputGroup.TabIndex = 9;
            this.InputGroup.TabStop = false;
            this.InputGroup.Text = "Input Group";
            // 
            // Chart
            // 
            chartArea1.Name = "ChartArea1";
            this.Chart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.Chart.Legends.Add(legend1);
            this.Chart.Location = new System.Drawing.Point(13, 195);
            this.Chart.Margin = new System.Windows.Forms.Padding(4);
            this.Chart.Name = "Chart";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series1.Legend = "Legend1";
            series1.Name = "Data_Values";
            series1.Points.Add(dataPoint1);
            series1.Points.Add(dataPoint2);
            series1.Points.Add(dataPoint3);
            this.Chart.Series.Add(series1);
            this.Chart.Size = new System.Drawing.Size(697, 314);
            this.Chart.TabIndex = 10;
            this.Chart.Text = "Chart";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(743, 535);
            this.Controls.Add(this.Chart);
            this.Controls.Add(this.InputGroup);
            this.Controls.Add(this.RadioGroup);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Assign4";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.RadioGroup.ResumeLayout(false);
            this.RadioGroup.PerformLayout();
            this.InputGroup.ResumeLayout(false);
            this.InputGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox TextInput;
        private System.Windows.Forms.GroupBox RadioGroup;
        private System.Windows.Forms.RadioButton RadioChart;
        private System.Windows.Forms.RadioButton RadioPie;
        private System.Windows.Forms.RadioButton RadioColumn;
        private System.Windows.Forms.RadioButton RadioBar;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ChooseFileButton;
        private System.Windows.Forms.Button FileValButton;
        private System.Windows.Forms.Button RandValButton;
        private System.Windows.Forms.Button UserValButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox InputGroup;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart;
    }
}

