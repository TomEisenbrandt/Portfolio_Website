﻿/*
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 473
SECTION:    1
PROJECT:    4
DUE DATE:   28th March 2018
*/

using System ;
using System.IO ;
using System.Collections.Generic ;
using System.ComponentModel ;
using System.Data ;
using System.Drawing ;
using System.Linq ;
using System.Text ;
using System.Threading.Tasks ;
using System.Windows.Forms ;

namespace Assignment4 {
    //
    public partial class Form1: Form {
        //
        public Form1( ){
        InitializeComponent( ) ;
        }// End of form constructor
        //
        double[ ] FileData = new double[ 30 ] ; // Holds data read in from file
        int COUNTER = 0 ; // Counts how many lines are read in
        int FileCounter = 0 ; // Amount of values in current file
        //
/************************************************
Form Load
************************************************/
        private void Form1_Load( object sender , EventArgs e ){
        //
        }// End of Form Load
        //
/************************************************
Exit Button
When user clicks the ExitButton the application exits
************************************************/
        private void ExitButton_Click( object sender , EventArgs e ){
        //
        Application.Exit( ) ; // Exit program
        }// End of Exit Button
        //
/************************************************
Clear Button
When user clicks this button text field is cleared.
************************************************/
        private void ClearButton_Click( object sender , EventArgs e ){
        //
        TextInput.Clear( ) ; // Clear text field
        RadioBar.Checked = false ; // Reset radio
        RadioColumn.Checked = false ; // Reset radio
        RadioPie.Checked = false ; // Reset radio
        RadioChart.Checked = false ; // Reset radio
        Chart.Series["Data_Values"].Points.Clear( ) ; // Clear chart data
        Chart.Series["Data_Values"].Points.AddY( 0.0 ) ; // Retain a single 0.0 value so chart won't 'vanish'
        }// End of Clear Button
        //
/************************************************
Choose File Button
User chooses file to be displayed
************************************************/
        private void ChooseFileButton_Click( object sender , EventArgs e ){
        //
        string LINE = "" ; // Holds streamed in string value
        int LineCount = 0 ; // Count input
        //
        OpenFileDialog OFD = new OpenFileDialog {
        InitialDirectory = "." // Set the starting directory
        } ;
        //
        try{
            if( OFD.ShowDialog( ) == DialogResult.OK ){
                //
                foreach( var Data in FileData ){ 
                Array.Clear( FileData , 0 , 30 ) ; // Reset array values
                }// End of foreach
                //
                StreamReader STREAM = new StreamReader( OFD.FileName ) ; // Open streamreader
                LINE = STREAM.ReadLine( ) ; // Start file stream
                //
                while( LINE != null ){ // Read file contents until stream 
                FileData[ LineCount ] = Convert.ToDouble( LINE ) ; // Convert streamed data to double and place in array
                LINE = STREAM.ReadLine( ) ; // Stream in next line
                LineCount++ ; // Increment count by 1
                }// End of while
                //
            STREAM.Close( ) ; // Close file stream
            FileCounter = LineCount ; // record number of input lines in file
            LineCount = 0 ; // Reset count
            }// End of if
            //
        }// End of try
        catch{ 
        MessageBox.Show( "Error opening file" ) ; // Error message
        }// End of catch
        }// End of Choose File Button
        //
/************************************************
Random Value Button
If button clicked make a double value in the range of 0.0 to 30.0
************************************************/
        private void RandValButton_Click( object sender , EventArgs e ){
        //
        double MinRand = 0.0 ; // Minimum random value
        double MaxRand = 30.0 ; // Maximum random value
        double DoubleRand = 0.0 ; // Holds random value
        //
        Random RAND = new Random( ) ; // Make random value
        DoubleRand = RAND.NextDouble(  ) * ( MaxRand - MinRand ) + MinRand  ; // convert random to double
        Chart.Series["Data_Values"].Points.AddY( DoubleRand ) ; // Add random value as point
        }// End of Random value Button
        //
/************************************************
Value from File Button
Select values from files to add as points
************************************************/
        private void FileValButton_Click( object sender , EventArgs e ){
        //
        if( COUNTER <= FileCounter ){ 
        Chart.Series["Data_Values"].Points.AddY( FileData[ COUNTER ] ) ; // Add data from array as data points on chart
        COUNTER ++ ; // Increment count
        }// End of if
        else{ 
        MessageBox.Show( "All current file values added. No more remaining input data." ) ; // Error message
        }// End of else
        //
        }// End of Value from File Button
        //
/************************************************
Value from user Button
************************************************/
        private void UserValButton_Click( object sender , EventArgs e ){
        //
        double MinDouble = 0.0 ; // Minimum value
        double MaxDouble = 30.0 ; // Maximum value
        double UserDouble = 0.0 ; // holds double value
        string UserVal = "" ; // Holds user input
        //
        try{
        UserVal = TextInput.Text ; // Get user input
        UserDouble = Convert.ToDouble( UserVal ) ; // convert user input to double
            if( UserDouble >= MinDouble || UserDouble <= MaxDouble){ 
            Chart.Series["Data_Values"].Points.AddY( UserDouble ) ; // Add user value as point
            }// End of if
            else{
            MessageBox.Show( "Please use values between 0.0 and 30.0" ) ; // Error message  
            }// End of else
        }// End of try        
        catch{ 
        MessageBox.Show( "Invalid input - Enter a decimal value" ) ; // Error message
        }// End of catch
        TextInput.Clear( ) ; // Clear text field
        }// End of Value from User Button
        //
/************************************************
Radio Button: Bar Chart
************************************************/
        private void RadioBar_CheckedChanged( object sender , EventArgs e ){
        //
        Chart.Series["Data_Values"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar ; // Change chart type to bar
        RadioBar.Checked = false ; // Reset radio
        }// End of RadioBar
        //
/************************************************
Radio Button: Column Chart
************************************************/
        private void RadioColumn_CheckedChanged( object sender , EventArgs e ){
        //
        Chart.Series["Data_Values"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column ; // Change chart type to column
        RadioColumn.Checked = false ; // Reset radio
        }// End of RadioColumn
        //
/************************************************
Radio Button: Pie Chart
************************************************/
        private void RadioPie_CheckedChanged( object sender , EventArgs e ){
        //
        Chart.Series["Data_Values"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie ; // Change chart type to pie
        RadioPie.Checked = false ; // Reset radio
        }// End of RadioPie
        //
/************************************************
Radio Button: Chart of choice( Doughnut )
************************************************/
        private void RadioChart_CheckedChanged( object sender , EventArgs e ){
        //
        Chart.Series["Data_Values"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut ; // Change chart type to doughnut
        RadioChart.Checked = false ; // Reset radio
        }// End of RadioChart
        //
    }// End of partial class
    //
}// End of namespace
//
/*
    END OF FILE
*/