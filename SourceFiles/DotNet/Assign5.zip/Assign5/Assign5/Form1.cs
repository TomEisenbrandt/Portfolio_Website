﻿/*
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 473
SECTION:    1
Project:    5
Due:        April 18th 2018 11:59PM
*/

using System ;
using System.IO ;
using System.Security.AccessControl ;
using System.Collections.Generic ;
using System.ComponentModel ;
using System.Data ;
using System.Drawing ;
using System.Linq ;
using System.Text ;
using System.Threading.Tasks ;
using System.Windows.Forms ;
using System.Timers ;
using System.Threading ;

namespace Assign5 {
//
    public partial class Assign5: Form {
    //
    string[ ] SiteData = new string[ 20 ] ; // Holds site names
    string[ ] UserData = new string[ 20 ] ; // Holds Usernames
    string[ ] PassData = new string[ 20 ] ; // Holds passwords
    int DataCount = 0 ; // Counts iterations
    //
        public Assign5( ){
        //
        InitializeComponent( ) ;
        }// End of contructor
        //
/****************************
Form Loader
    Loads in items as the form starts
****************************/
        private void Assign5_Load( object sender , EventArgs e ){
        //
        }// End of LOAD
        //
/****************************
Exit Button
    Exits the program
****************************/
        private void ExitButton_Click( object sender , EventArgs e ){
        //
        Application.Exit( ) ; // Exit the application
        }// End of ExitButton
        //
/****************************
Master Enter Button
    Takes input from user.
    Compares user input to a string stored in an encrypted file
    If string and input match then user gains access.
    Upon gaining access, dataset values are loaded in
****************************/
        private void MasterEnterButton_Click( object sender , EventArgs e ){
        //
        string MasterFile = "MasterPass.txt" ; // Name of file holding master password
        string MasterPassInput = "" ; // Hods user's master password value
        string MasterLine = "" ; // Holds streamed in data
        //
        MasterPassInput = MasterText.Text ; // Take in user's master password value
        File.Decrypt( MasterFile ) ; // Decryrpt the file
        StreamReader MasterStream = new StreamReader( MasterFile ) ; // Open file stream
        MasterLine = MasterStream.ReadLine( ) ; // Stream in password value from file
        MasterStream.Close( ) ; // Close the stream
        File.Encrypt( MasterFile ) ; // Re-Encrypt the file
        //
            if( MasterPassInput == MasterLine ){ // If user input matches master password
            //
            string AccountInfo = "Passwords.txt" ; // Filename of the file that holds account info
            string AccountLine = "" ; // Holds streamed in account info
            char Delimiter = ',' ; // Delimiter for string split
            //
            File.Decrypt( AccountInfo ) ; // Decrypt the file
            StreamReader AccountStream = new StreamReader( AccountInfo ) ; // Open stream for account info
            AccountLine = AccountStream.ReadLine( ) ; // Read line
            //
                while( AccountLine != null ){ // While the file stream does not equal null
                //
                string [ ] AccountArray = AccountLine.Split( Delimiter ) ; // Stream data into an array and split the input via delimiter
                SiteData[ DataCount ] = AccountArray[ 0 ] ; // Insert site data
                UserData[ DataCount ] = AccountArray[ 1 ] ; // Insert user data
                PassData[ DataCount ] = AccountArray[ 2 ] ; // Insert password data
                DataList.Items.Add( SiteData[ DataCount ] ) ; // Add data to the listbox
                AccountLine = AccountStream.ReadLine( ) ; // Read next line
                DataCount++ ; // Increment count by one
                }// End of while
                //
            AccountStream.Close( ) ; // Close the streamed file
            File.Encrypt( AccountInfo ) ; // Re-Encrypt the file
            MasterText.Clear( ) ; // Clear textbox
            MainGroup.Visible = true ; // Enable MainGroup visibility
            MainGroup.Enabled = true ; // Enable MainGroup
            //MessageBox.Show( "Welcome!" ) ; // DEBUG / Success message
            }// End of if
            else{ // if user input does not match master password
            MessageBox.Show( "Invalid password" ) ; // If user input does not match password value an error message occurs. 
            }// End of else
            //
        }// End of EnterButton
        //
/****************************
New Data Button
    User supplies input in textboxes
    Values added to data set
    New Site name values added to ListBox
****************************/
        private void NewDataButton_Click( object sender , EventArgs e ) {
        //
        string SITE = "" ; // Holds site name data
        string USER = "" ; // Holds userID input data
        string PASS = "" ; // Holds password input data
        bool Valid = false ; // If input is not null Valid = true
        //
        SITE = SiteField.Text ; // Take user input for new site
        USER = UserIDField.Text ; // Take user input for new user
        PASS = PasswordField.Text ; // Take user input for new password
        //
        if( SITE == null || USER == null || PASS == null ) { 
        MessageBox.Show( "Invalid input" ) ; // Error message
        }// End of if
        else{ 
        Valid = true ;
        }// End of else
        //
            if( Valid == true && PASS.Length >= 8 && PASS.Any( char.IsUpper ) && PASS.Any( char.IsLower ) && PASS.Any( char.IsDigit ) ) {
            SiteData[ DataCount ] = SITE ; // Insert site data
            UserData[ DataCount ] = USER ; // Insert user data
            PassData[ DataCount ] = PASS ; // Insert password data
            DataList.Items.Add( SiteData[ DataCount ] ) ; // Add data to the listbox
            DataCount++ ; // Increment count by one 
            } // End of if 
            else{ 
            MessageBox.Show( "Invalid password" ) ; // Error message
            } // End of else
            //
        SiteField.Clear( ) ; // Reset textbox 
        UserIDField.Clear( ) ; // Reset textbox 
        PasswordField.Clear( ) ; // Reset textbox
        } // End of New Data Button
        //
/****************************
Modify Data Button
    Allow the user to change password values
    New password values are to be supplied via textbox
****************************/
        private void ModifyDataButton_Click( object sender , EventArgs e ) {
        //
        string SITE = "" ; // Holds site name data
        string NewPass = "" ; // Holds new password value
        int DataListIndex = 0 ; // Indexer
        //
        NewPass = PasswordField.Text ; // Take in the users input for a new password
        if( NewPass.Length >= 8 && NewPass.Any( char.IsUpper ) && NewPass.Any( char.IsLower ) && NewPass.Any( char.IsDigit ) ) {
        //
            try{
            SITE = DataList.SelectedItem.ToString( ) ; // Finds the selected item
            }// End of try
            catch{ 
            MessageBox.Show( "Please Select Site from list." ) ; // Error message
            }// End of catch
            DataListIndex = DataList.FindString( SITE ) ; // Finds the string value
                if( DataListIndex == -1 ) {
                MessageBox.Show( "Error - DataList Indexing" ) ; // Error message
                }// End of if
                else{
                    for( int i = 0 ; i < SiteData.Length ; i++ ) {
                        if( SiteData[ i ] == SITE ){
                        PassData[ i ] = NewPass ; // Assign new password
                        }// End of if
                        //
                    }// End of for            
                    //
                }// End of else
                //
            }// End of if( is input value valid)
            else{ 
            MessageBox.Show( "Improper password" ) ;
            }// End of else
            //
        SiteField.Clear( ) ; // Reset textbox 
        UserIDField.Clear( ) ; // Reset textbox 
        PasswordField.Clear( ) ; // Reset textbox
        } // End of ModifyDataButton
        //
/****************************
Delete Data Button
    User selects a value from the listbox
    Selected sitename value and its associate data are 'nulled out'
        As shown in the Save & Quit Button, null values are ignored upon writing out the final data result
****************************/
        private void DeleteDataButton_Click( object sender , EventArgs e ) {
        //
        string SITE = "" ; // Holds site name data
        int DataListIndex = 0 ; // Indexer
        //
        try{
        SITE = DataList.SelectedItem.ToString( ) ; // Finds the selected item
        }// End of try
        catch{ 
        MessageBox.Show( "Please Select Site from list." ) ; // Error message
        }// End of catch
        DataListIndex = DataList.FindString( SITE ) ; // Finds the string value
            if( DataListIndex == -1 ) {
            MessageBox.Show( "Error - DataList Indexing" ) ; // Error message
            }// End of if
            else{
                for( int i = 0 ; i < SiteData.Length ; i++ ) {
                    if( SiteData[ i ] == SITE ){
                    DataList.Items.Remove( SITE ) ; // Remove from list box
                    SiteData[ i ] = null ;
                    UserData[ i ] = null ;
                    PassData[ i ] = null ;
                    }// End of if
                    //
                }// End of for            
                //
            }// End of else
            //
        SiteField.Clear( ) ; // Reset textbox 
        UserIDField.Clear( ) ; // Reset textbox 
        PasswordField.Clear( ) ; // Reset textbox
        } // End of DeleteDataButton
        //
/****************************
Show Data Button
    Shows the username and password(protected)
    for the selected item in list
****************************/
        private void ShowDataButton_Click( object sender , EventArgs e ) {
        //
        string SITE = "" ; // Holds site name data
        string SiteResult = "" ; // Holds site name string
        string UserResult = "" ; // Holds username string
        string PassResult = "" ; // Holds password string
        string HiddenPassword = "********" ; // Fake password
        int DataListIndex = 0 ; // Indexer
        //
        DataViewer.Items.Clear( ) ; // Clear the listbox
        try{
        SITE = DataList.SelectedItem.ToString( ) ; // Finds the selected item
        }// End of try
        catch{ 
        MessageBox.Show( "Please Select Site from list." ) ; // Error message
        }// End of catch
        DataListIndex = DataList.FindString( SITE ) ; // Finds the string value
            if( DataListIndex == -1 ) {
            MessageBox.Show( "Error - DataList Indexing" ) ; // Error message
            }// End of if
            else{
                for( int i = 0 ; i < SiteData.Length ; i++ ) {
                    if( SiteData[ i ] == SITE ) {
                    SiteResult = string.Format( "Website: {0}" , SiteData[ i ] ) ; // Format string
                    UserResult = string.Format( "Username: {0}" , UserData[ i ] ) ; // Format string
                    PassResult = string.Format( "Password: {0}" , HiddenPassword ) ; // Format string
                    DataViewer.Items.Add( SiteResult ) ; // Add site name to listbox
                    DataViewer.Items.Add( UserResult ) ; // Add username to listbox
                    DataViewer.Items.Add( PassResult ) ; // Add password to listbox
                    }// End of if
                    //
                }// End of for            
                //
            }// End of else
            //
        }// End of ShowDataButton
        //
/****************************
Show Password Button
    Password value for chosen data is displayed
    Display of password only lasts a limited time
****************************/
        private void ShowPassButton_Click( object sender , EventArgs e ) {
        //
        string SITE = "" ; // Holds site name data
        string SiteResult = "" ; // Holds site name string
        string UserResult = "" ; // Holds username string
        string PassResult = "" ; // Holds password string
        int DataListIndex = 0 ; // Indexer
        //
        DataViewer.Items.Clear( ) ; // Clear the listbox
        try{
        SITE = DataList.SelectedItem.ToString( ) ; // Finds the selected item
        }// End of try
        catch{ 
        MessageBox.Show( "Please Select Site from list." ) ; // Error message
        }// End of catch
        DataListIndex = DataList.FindString( SITE ) ; // Finds the string value
            if( DataListIndex == -1 ) {
            MessageBox.Show( "Error - DataList Indexing" ) ; // Error message
            }// End of if
            else{
                for( int i = 0 ; i < SiteData.Length ; i++ ) {
                    if( SiteData[ i ] == SITE ){
                    SiteResult = string.Format( "Website: {0}" , SiteData[ i ] ) ; // Format string
                    UserResult = string.Format( "Username: {0}" , UserData[ i ] ) ; // Format string
                    PassResult = string.Format( "Password: {0}" , PassData[ i ] ) ; // Format string
                    DataViewer.Items.Add( SiteResult ) ; // Add site name to listbox
                    DataViewer.Items.Add( UserResult ) ; // Add username to listbox
                    DataViewer.Items.Add( PassResult ) ; // Add password to listbox
                    PasswordTimer.Start( ) ; // Start the timer for showing the password
                    }// End of if
                    //
                }// End of for            
                //
            }// End of else
            //
        }// End of ShowPasswordButton
        //
/****************************
Password Textbox Field
    Changes all text in the field to asterisks
****************************/
        private void PasswordField_TextChanged( object sender , EventArgs e ) {
        //
        PasswordField.PasswordChar = '*' ; // Changes all input in textbox to asterisk '*'
        }// End of Password Field textbox modifier
        //
/****************************
Save + Quit Button
    Writes out the data to the original data set file
    overwrites any previous data with new data
        datasets with null values are ignored(deleted)
****************************/
        private void SaveQuitButton_Click( object sender , EventArgs e ) {
        //
        string PasswordFile = "Passwords.txt" ; // Passwords file
        string LineWriter = "" ; // Holds formated string to write to file
        //
        File.Decrypt( PasswordFile ) ; // Decrypt the file
        using( StreamWriter WRITER = new StreamWriter( PasswordFile ) ){
        //
            for( int i = 0 ; i < SiteData.Length ; i++ ) {
            //
                if( SiteData[ i ] != null && UserData != null && PassData[ i ] != null ) { // Only write non null values( null values = deleted from dataset )
                LineWriter = string.Format( SiteData[ i ] + "," + UserData[ i ] + "," + PassData[ i ] ) ; // Format string to write  
                WRITER.WriteLine( LineWriter ) ; // Write to file
                }// End of if        
                //
            }// End of for
            //
        WRITER.Close( ) ; // Close connection
        }// End of using(StreamWriter)
        File.Encrypt( PasswordFile ) ; // Encrypt the file
        Application.Exit( ) ; // Exit the application
        }// End of Save and Quit button
        //
/****************************
Password Viewing Timer
    Timer has an interval of 8000( 8 seconds )
    After time has expired the listbox showing the password resets
****************************/
        private void PasswordTimer_Tick( object sender , EventArgs e ) {
        //
        PasswordTimer.Stop( ) ; // Stop timer
        DataViewer.Items.Clear( ) ; // Clear the listbox
        MessageBox.Show( "View time expired" ) ;
        }// End of PasswordTimer tick
        //
    }// End of partial class
    //
}// End of namespace
//

/*
END OF FILE 
*/

