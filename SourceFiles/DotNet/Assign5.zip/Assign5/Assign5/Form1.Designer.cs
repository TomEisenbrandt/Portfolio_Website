﻿namespace Assign5
{
    partial class Assign5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ExitButton = new System.Windows.Forms.Button();
            this.MasterText = new System.Windows.Forms.TextBox();
            this.MasterEnterButton = new System.Windows.Forms.Button();
            this.MasterGroup = new System.Windows.Forms.GroupBox();
            this.MasterLabel = new System.Windows.Forms.Label();
            this.MainGroup = new System.Windows.Forms.GroupBox();
            this.DataList = new System.Windows.Forms.ListBox();
            this.ModifyDataButton = new System.Windows.Forms.Button();
            this.DeleteDataButton = new System.Windows.Forms.Button();
            this.NewDataButton = new System.Windows.Forms.Button();
            this.ShowPassButton = new System.Windows.Forms.Button();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.UserLabel = new System.Windows.Forms.Label();
            this.WebsiteLabel = new System.Windows.Forms.Label();
            this.PasswordField = new System.Windows.Forms.TextBox();
            this.UserIDField = new System.Windows.Forms.TextBox();
            this.SiteField = new System.Windows.Forms.TextBox();
            this.SaveQuitButton = new System.Windows.Forms.Button();
            this.ShowDataButton = new System.Windows.Forms.Button();
            this.PasswordTimer = new System.Windows.Forms.Timer(this.components);
            this.DataViewer = new System.Windows.Forms.ListBox();
            this.MasterGroup.SuspendLayout();
            this.MainGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(612, 20);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(150, 58);
            this.ExitButton.TabIndex = 0;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // MasterText
            // 
            this.MasterText.Location = new System.Drawing.Point(132, 52);
            this.MasterText.Margin = new System.Windows.Forms.Padding(4);
            this.MasterText.Name = "MasterText";
            this.MasterText.Size = new System.Drawing.Size(318, 26);
            this.MasterText.TabIndex = 1;
            // 
            // MasterEnterButton
            // 
            this.MasterEnterButton.Location = new System.Drawing.Point(456, 20);
            this.MasterEnterButton.Margin = new System.Windows.Forms.Padding(4);
            this.MasterEnterButton.Name = "MasterEnterButton";
            this.MasterEnterButton.Size = new System.Drawing.Size(150, 58);
            this.MasterEnterButton.TabIndex = 2;
            this.MasterEnterButton.Text = "Enter";
            this.MasterEnterButton.UseVisualStyleBackColor = true;
            this.MasterEnterButton.Click += new System.EventHandler(this.MasterEnterButton_Click);
            // 
            // MasterGroup
            // 
            this.MasterGroup.Controls.Add(this.MasterLabel);
            this.MasterGroup.Controls.Add(this.MasterText);
            this.MasterGroup.Controls.Add(this.ExitButton);
            this.MasterGroup.Controls.Add(this.MasterEnterButton);
            this.MasterGroup.Location = new System.Drawing.Point(18, 18);
            this.MasterGroup.Margin = new System.Windows.Forms.Padding(4);
            this.MasterGroup.Name = "MasterGroup";
            this.MasterGroup.Padding = new System.Windows.Forms.Padding(4);
            this.MasterGroup.Size = new System.Drawing.Size(800, 109);
            this.MasterGroup.TabIndex = 3;
            this.MasterGroup.TabStop = false;
            this.MasterGroup.Text = "Master Group";
            // 
            // MasterLabel
            // 
            this.MasterLabel.AutoSize = true;
            this.MasterLabel.Location = new System.Drawing.Point(128, 23);
            this.MasterLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MasterLabel.Name = "MasterLabel";
            this.MasterLabel.Size = new System.Drawing.Size(116, 19);
            this.MasterLabel.TabIndex = 3;
            this.MasterLabel.Text = "Master Password";
            // 
            // MainGroup
            // 
            this.MainGroup.Controls.Add(this.DataViewer);
            this.MainGroup.Controls.Add(this.ShowDataButton);
            this.MainGroup.Controls.Add(this.SaveQuitButton);
            this.MainGroup.Controls.Add(this.DataList);
            this.MainGroup.Controls.Add(this.ModifyDataButton);
            this.MainGroup.Controls.Add(this.DeleteDataButton);
            this.MainGroup.Controls.Add(this.NewDataButton);
            this.MainGroup.Controls.Add(this.ShowPassButton);
            this.MainGroup.Controls.Add(this.PasswordLabel);
            this.MainGroup.Controls.Add(this.UserLabel);
            this.MainGroup.Controls.Add(this.WebsiteLabel);
            this.MainGroup.Controls.Add(this.PasswordField);
            this.MainGroup.Controls.Add(this.UserIDField);
            this.MainGroup.Controls.Add(this.SiteField);
            this.MainGroup.Enabled = false;
            this.MainGroup.Location = new System.Drawing.Point(18, 135);
            this.MainGroup.Margin = new System.Windows.Forms.Padding(4);
            this.MainGroup.Name = "MainGroup";
            this.MainGroup.Padding = new System.Windows.Forms.Padding(4);
            this.MainGroup.Size = new System.Drawing.Size(800, 426);
            this.MainGroup.TabIndex = 3;
            this.MainGroup.TabStop = false;
            this.MainGroup.Text = "Main Group";
            this.MainGroup.Visible = false;
            // 
            // DataList
            // 
            this.DataList.FormattingEnabled = true;
            this.DataList.ItemHeight = 19;
            this.DataList.Location = new System.Drawing.Point(167, 30);
            this.DataList.Name = "DataList";
            this.DataList.Size = new System.Drawing.Size(283, 365);
            this.DataList.TabIndex = 9;
            // 
            // ModifyDataButton
            // 
            this.ModifyDataButton.Location = new System.Drawing.Point(456, 109);
            this.ModifyDataButton.Name = "ModifyDataButton";
            this.ModifyDataButton.Size = new System.Drawing.Size(150, 58);
            this.ModifyDataButton.TabIndex = 8;
            this.ModifyDataButton.Text = "Modify Data";
            this.ModifyDataButton.UseVisualStyleBackColor = true;
            this.ModifyDataButton.Click += new System.EventHandler(this.ModifyDataButton_Click);
            // 
            // DeleteDataButton
            // 
            this.DeleteDataButton.Location = new System.Drawing.Point(456, 193);
            this.DeleteDataButton.Name = "DeleteDataButton";
            this.DeleteDataButton.Size = new System.Drawing.Size(150, 58);
            this.DeleteDataButton.TabIndex = 7;
            this.DeleteDataButton.Text = "Delete Data";
            this.DeleteDataButton.UseVisualStyleBackColor = true;
            this.DeleteDataButton.Click += new System.EventHandler(this.DeleteDataButton_Click);
            // 
            // NewDataButton
            // 
            this.NewDataButton.Location = new System.Drawing.Point(456, 30);
            this.NewDataButton.Name = "NewDataButton";
            this.NewDataButton.Size = new System.Drawing.Size(150, 58);
            this.NewDataButton.TabIndex = 6;
            this.NewDataButton.Text = "New Data";
            this.NewDataButton.UseVisualStyleBackColor = true;
            this.NewDataButton.Click += new System.EventHandler(this.NewDataButton_Click);
            // 
            // ShowPassButton
            // 
            this.ShowPassButton.Location = new System.Drawing.Point(612, 109);
            this.ShowPassButton.Name = "ShowPassButton";
            this.ShowPassButton.Size = new System.Drawing.Size(150, 58);
            this.ShowPassButton.TabIndex = 4;
            this.ShowPassButton.Text = "Show Password";
            this.ShowPassButton.UseVisualStyleBackColor = true;
            this.ShowPassButton.Click += new System.EventHandler(this.ShowPassButton_Click);
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Location = new System.Drawing.Point(8, 173);
            this.PasswordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(69, 19);
            this.PasswordLabel.TabIndex = 5;
            this.PasswordLabel.Text = "Password";
            // 
            // UserLabel
            // 
            this.UserLabel.AutoSize = true;
            this.UserLabel.Location = new System.Drawing.Point(8, 97);
            this.UserLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UserLabel.Name = "UserLabel";
            this.UserLabel.Size = new System.Drawing.Size(70, 19);
            this.UserLabel.TabIndex = 4;
            this.UserLabel.Text = "Username";
            // 
            // WebsiteLabel
            // 
            this.WebsiteLabel.AutoSize = true;
            this.WebsiteLabel.Location = new System.Drawing.Point(8, 23);
            this.WebsiteLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WebsiteLabel.Name = "WebsiteLabel";
            this.WebsiteLabel.Size = new System.Drawing.Size(58, 19);
            this.WebsiteLabel.TabIndex = 3;
            this.WebsiteLabel.Text = "Website";
            // 
            // PasswordField
            // 
            this.PasswordField.Location = new System.Drawing.Point(12, 196);
            this.PasswordField.Margin = new System.Windows.Forms.Padding(4);
            this.PasswordField.Name = "PasswordField";
            this.PasswordField.Size = new System.Drawing.Size(148, 26);
            this.PasswordField.TabIndex = 2;
            this.PasswordField.TextChanged += new System.EventHandler(this.PasswordField_TextChanged);
            // 
            // UserIDField
            // 
            this.UserIDField.Location = new System.Drawing.Point(12, 120);
            this.UserIDField.Margin = new System.Windows.Forms.Padding(4);
            this.UserIDField.Name = "UserIDField";
            this.UserIDField.Size = new System.Drawing.Size(148, 26);
            this.UserIDField.TabIndex = 1;
            // 
            // SiteField
            // 
            this.SiteField.Location = new System.Drawing.Point(12, 47);
            this.SiteField.Margin = new System.Windows.Forms.Padding(4);
            this.SiteField.Name = "SiteField";
            this.SiteField.Size = new System.Drawing.Size(148, 26);
            this.SiteField.TabIndex = 0;
            // 
            // SaveQuitButton
            // 
            this.SaveQuitButton.Location = new System.Drawing.Point(612, 193);
            this.SaveQuitButton.Name = "SaveQuitButton";
            this.SaveQuitButton.Size = new System.Drawing.Size(150, 58);
            this.SaveQuitButton.TabIndex = 4;
            this.SaveQuitButton.Text = "Save + Quit";
            this.SaveQuitButton.UseVisualStyleBackColor = true;
            this.SaveQuitButton.Click += new System.EventHandler(this.SaveQuitButton_Click);
            // 
            // ShowDataButton
            // 
            this.ShowDataButton.Location = new System.Drawing.Point(612, 30);
            this.ShowDataButton.Name = "ShowDataButton";
            this.ShowDataButton.Size = new System.Drawing.Size(150, 58);
            this.ShowDataButton.TabIndex = 10;
            this.ShowDataButton.Text = "Show Data";
            this.ShowDataButton.UseVisualStyleBackColor = true;
            this.ShowDataButton.Click += new System.EventHandler(this.ShowDataButton_Click);
            // 
            // PasswordTimer
            // 
            this.PasswordTimer.Interval = 8000;
            this.PasswordTimer.Tick += new System.EventHandler(this.PasswordTimer_Tick);
            // 
            // DataViewer
            // 
            this.DataViewer.FormattingEnabled = true;
            this.DataViewer.ItemHeight = 19;
            this.DataViewer.Location = new System.Drawing.Point(456, 257);
            this.DataViewer.Name = "DataViewer";
            this.DataViewer.Size = new System.Drawing.Size(306, 137);
            this.DataViewer.TabIndex = 11;
            // 
            // Assign5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(855, 574);
            this.Controls.Add(this.MainGroup);
            this.Controls.Add(this.MasterGroup);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Assign5";
            this.Text = "Project 5";
            this.Load += new System.EventHandler(this.Assign5_Load);
            this.MasterGroup.ResumeLayout(false);
            this.MasterGroup.PerformLayout();
            this.MainGroup.ResumeLayout(false);
            this.MainGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.TextBox MasterText;
        private System.Windows.Forms.Button MasterEnterButton;
        private System.Windows.Forms.GroupBox MasterGroup;
        private System.Windows.Forms.GroupBox MainGroup;
        private System.Windows.Forms.Label MasterLabel;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.Label UserLabel;
        private System.Windows.Forms.Label WebsiteLabel;
        private System.Windows.Forms.TextBox PasswordField;
        private System.Windows.Forms.TextBox UserIDField;
        private System.Windows.Forms.TextBox SiteField;
        private System.Windows.Forms.ListBox DataList;
        private System.Windows.Forms.Button ModifyDataButton;
        private System.Windows.Forms.Button DeleteDataButton;
        private System.Windows.Forms.Button NewDataButton;
        private System.Windows.Forms.Button ShowPassButton;
        private System.Windows.Forms.Button SaveQuitButton;
        private System.Windows.Forms.Button ShowDataButton;
        private System.Windows.Forms.Timer PasswordTimer;
        private System.Windows.Forms.ListBox DataViewer;
    }
}

