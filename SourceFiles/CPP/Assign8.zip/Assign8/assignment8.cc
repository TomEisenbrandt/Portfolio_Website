/*
FILE INFO
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 340
SECTION:    03
PROJECT:    08
DUE DATE:   April 20th 2017 11:59 PM
FILENAME:   assignment8.cc
*/

#include "assignment8.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>

using namespace std;

/*******************************************************************************************/

/*
FUNCTION:       Entry* get_entry( const string& lineInput )
PARAMETER(S):   const string& lineInput
RETURN:         Data read in from file
PURPOSE:        Reads input from file
*/
Entry* get_entry( const string& lineInput ) {

//Hold key and desciption of input
Entry* parsedInput = new Entry ;
parsedInput -> key = lineInput.substr( 2 , 3 ) ;
parsedInput -> description = lineInput.substr( 6 , lineInput.length( ) - 6 ) ;
return parsedInput ;

}

/*******************************************************************************************/

/*
FUNCTION:       string get_key( const string& input )
PARAMETER(S):   const string& input
RETURN:         String
PURPOSE:		Lines read from input are processed
*/
string get_key( const string& lineInput ) {

string getKey = lineInput.substr( 2 , 3 ) ;
return getKey ;

}

/*******************************************************************************************/

/*
FUNCTION:       HT::HT( int s = 11 )
PARAMETER(S):   int s = 11
RETURN:         None
PURPOSE:        Default constructor
*/
HT::HT( int s = 11 ) {

hTable = new vector< Entry >( s ) ;
table_size = s ;
item_count = 0 ;

}

/*******************************************************************************************/

/*
FUNCTION:       HT::~HT( )
PARAMETER(S):   Void
RETURN:         None
PURPOSE:        Destrcutor - deallocate memory
*/
HT::~HT( ) {
delete hTable ;
}

/*******************************************************************************************/

/*
FUNCTION:       int HT::search ( const string& key )
PARAMETER(S):   const string& key
RETURN:         Position of itemif found, if not found return -1
PURPOSE:        Searches hash table via key
*/
int HT::search ( const string& key ) {

// Finds the value via hash key
int hashIndex = hashing( key ) ;

	for( int i = 0 ; i < table_size ; i++ ) {

		if ( ( *hTable )[ hashIndex ].key == key ) {

// Return the found position
		return hashIndex ;

		}

//Increment the keyIndex
	hashIndex = ( hashIndex + 1 ) % table_size ;

	}

// If search fails returns -1 as a default
return -1 ;

}

/*******************************************************************************************/

/*
FUNCTION:       bool HT::insert( const Entry& e )
PARAMETER(S):   const Entry& e
RETURN:         Boolean
PURPOSE:        Insert into hash table
True    >   Item inserted to table
False   >   Hash table full / matching key
*/
bool HT::insert( const Entry& e ) {

int keyIndex = hashing( e.key ) ;
string sKey = e.key ;

// Unsuccessful search
	if( search( sKey ) != -1 ) {

	cerr << "Unable to insert - identical key found" << endl ;
	return false ;

	}

// Table is full
	else if( item_count == table_size ) {
	cerr << "Unable to insert - the table is full." << endl ;
	return false ;

	}

	else {

	int i ;

		for( i = 0 ; i < table_size ; i++ ) {

			if( ( *hTable )[ keyIndex ].key == "---" || ( *hTable )[ keyIndex ].key == "+++" ) {

			( *hTable )[ keyIndex ] = e ;
			item_count++ ;
// Returns true if all tests are passed
			return true ;

			}

		keyIndex = keyIndex + 1 % table_size ;

		}

	}

// Default return
return false ;

}

/*******************************************************************************************/

/*
FUNCTION:       bool HT::remove( const string& s )
PARAMETER(S):   const string& s
RETURN:         Boolean
PURPOSE:        Searches table for key
True		>   Key removed from table, item count reduced
False		>	Key not found during search
*/
bool HT::remove( const string& s ) {

	if ( search( s ) == -1 ) {

	return false ;

	}

	else {

	int keyIndex = search( s ) ;
	( *hTable )[ keyIndex ].key = "+++" ;
	item_count-- ;
	return true ;

	}

}

/*******************************************************************************************/

/*
FUNCTION:       void HT::print ( )
PARAMETER(S):   Void
RETURN:         None
PURPOSE:        Prints the table of data
*/
void HT::print( ) {

cout << "\n" ;
cout << "----Hash Table-----" ;
cout << "\n" ;

	for( int i = 0 ; i < table_size ; i++ ) {

		if( ( *hTable )[ i ].key != "---" && ( *hTable )[ i ].key != "+++" ) {

		cout << right << setw( 2 ) << i << ": " ;
		cout << ( *hTable )[ i ].key << " " ;
		cout << ( *hTable )[ i ].description ;
		cout << "\n" ;

		}

	}

cout << "-------------------" ;
cout << "\n" ;
cout << "\n" ;

}



/*******************************************************************************************/

/*	*	*	*	Given source code below this point	*	*	*	*	*	*	*	*	*	*	*/

/*******************************************************************************************/



// key is in form of letter-letter-digit
// compute sum <-- ascii(pos1)+ascii(pos2)+ascii(pos3)
// compute sum%htable_size
int HT::hashing(const string& key) {
   return ((int)key[0] + (int)key[1] + (int)key[2])%table_size;
}

int main(int argc, char** argv ) {
    if ( argc < 2 ) {
        cerr << "argument: file-name\n";
        return 1;
    }

    HT ht;
    ifstream infile(argv[1], ios::in);
    string line;
    infile >> line;    
    while ( !infile.eof() ) {
        if ( line[0] == 'A' ) { 
            Entry* e = get_entry( line );
            ht.insert( *e );
            delete e;
        }
        else {
            string key = get_key(line);
            if ( line[0] == 'D' ) {
                cout << "Removing " << key << "...\n";
                bool removed = ht.remove( key );
                if ( removed )
                    cout << key << " is removed successfully...\n\n";
                else
                    cout << key << " does not exist, no key is removed...\n\n";
            }
            else if ( line[0] == 'S' ) {
                int found = ht.search( key );
                if ( found < 0 ) 
                    cout << key << " does not exit in the hash table ..." << endl << endl;
                else
                   cout << key << " is found at table position " << found << endl << endl;
            }
            else if ( line[0] == 'P' ) {
                cout << "\nDisplaying the table: " << endl;
                ht.print();
            }
            else
                cerr << "wrong input: " << line << endl;
        }
        infile >> line;
 
    }

    infile.close();
    return 0;
}



/*****/

// END OF FILE

/*****/
