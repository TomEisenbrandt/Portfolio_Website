/*************************************
FILE INFO                           //
NAME:       Tom Eisenbrandt         //
ZID:        Z1771209                //
CLASS:      CSCI 340                //
SECTION:    03                      //
PROJECT:    04                      //
DUE:        March 1st 11:59 PM      //
FILENAME:   asignment4.h			//
*************************************/

using namespace std;

#ifndef ASSIGNMNET4_H
#define ASSIGNMENT4_H
#include <queue>

class Stack {
    private:
        std::queue<int> q1, q2;
    public:
        bool empty() const;
        int size() const;
        int top();
        void push(const int& val);
        void pop();
};

#endif


//

//  END OF FILE

//






