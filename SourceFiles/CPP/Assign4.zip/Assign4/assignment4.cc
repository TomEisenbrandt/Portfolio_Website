/*************************************
FILE INFO                           //
NAME:       Tom Eisenbrandt         //
ZID:        Z1771209                //
CLASS:      CSCI 340                //
SECTION:    03                      //
PROJECT:    04                      //
DUE:        March 1st 11:59 PM      //
FILENAME:   asignment4.cc           //
*************************************/

#include "assignment4.h"	//  Header file
#include <iostream>			//  Stream in/out
#include <iomanip>			//  Output manipulation
#include <string>			//  Strings
#include <stack>			//  Stacks
//#include <stdio.h>			//	NULL, printf
//#include <stdlib.h>			//	srand, rand
//#include <time.h>			//	Time
#include <cstdlib>          //  ~
#include <fstream>			//  File stream
using namespace std ;   	//  Exclude need of std::

/*************************************************************************************************************
FUNCTION:   bool Stack::empty( ) const
PARAMETERS: None
RETURN:     True if empty False otherwise
PURPOSE:    Check if queues are empty
*************************************************************************************************************/
bool Stack::empty( ) const {	//	START FUNCTION bool Stack::empty( )
bool gate = false ; //  Gate declared as false
	if( q1.empty( ) && q2.empty( ) ) {  //  If q1 and q2 are empty
	gate = true ;   					//  Gate switched to true
	}   								//  End if
return  gate;	//  Return value of gate
}   //  END FUNCTION bool Stack::empty( )

/*************************************************************************************************************
FUNCTION:   int Stack::size( ) const
PARAMETERS: None
RETURN:     Queue size
PURPOSE:    Find size of queues summed
*************************************************************************************************************/
int Stack::size( ) const {  //  START FUNCTION int Stack::size( ) const
int sizeSum = 0 ;	//	sizeSum declared at 0
sizeSum = q1.size( ) + q2.size( ) ; //  Get sum of sizes
return sizeSum ;    //  Return value of sizeSum ( size q1 + q2 )
}   //  END FUNCTION int Stack::size( ) const

/*************************************************************************************************************
FUNCTION:   int Stack::top( )
PARAMETERS: None
RETURN:     Top of queue
PURPOSE:    Find top of queue (front)
*************************************************************************************************************/
int Stack::top( ) { //  START FUNCTION int Stack::top( )
	if( !q1.empty( ) ) {    //  If q1 is not empty
	return q1.back( ) ;     //  return newest q1 value(using back instead of front for stack)
	}                       //  End if
		else{	//  Else->if q2 is not empty
		return q2.back( ) ;			//  return newest q2 value(using back instead of front for stack)
		}       					//  End of else if
}   //  END FUNCTION int Stack::top( )

/*************************************************************************************************************
FUNCTION:   void Stack::push( const int& val )
PARAMETERS: const int& val
RETURN:     None
PURPOSE:    Push queue with given paramter val
*************************************************************************************************************/
void Stack::push( const int& val ) {    //  START FUNCTION void Stack::push( const int& val )
if( q1.empty( ) && q2.empty( ) ) {    //  If q1 & q2 are empty
q1.push( val ) ;   //  push q1 with val
}

	else if( q1.empty( ) ) {    //  If q1 is empty
	q1.push( val ) ;
		while( !q2.empty( ) ) {     //  copy from q1 to q1
		q1.push( q2.front( ) ) ;
		}
	}

		else if( q2.empty( ) ) {    //  If q2 is empty
		q1.push( val ) ;
}


			else{
				while( !q2.empty( ) ) { //copy everything from q2 into q1
				q1.push( q2.front( ) ) ;
				}
			q1.push( val ) ; //then push new element into q1
			}

}   //  END FUNCTION void Stack::push( const int& val )

/*************************************************************************************************************
FUNCTION:   void Stack::pop( )
PARAMETERS: None
RETURN:     None
PURPOSE:    Pop queue front and then transfer queue over
*************************************************************************************************************/
void Stack::pop( ) {    //  START FUNCTION void Stack::pop( )
	while( q1.front( ) != q1.back( ) ) { //  copy all except top into q2
	q2.push( q1.front( ) ) ;
	q1.pop( ) ;   //  pop q1
	}

q1.pop( ) ;   //  pop top element of q1

		while( !q2.empty( ) ) {
		q1.push(q2.front( ) ) ; //  Copy from q2 to q1
		q2.pop( ) ; //  deallocate q2
		}
}   //  END FUNCTION void Stack::pop( )

/************************************************************************************************************/

int main() {
    Stack s;
    string op;
    int val = 0;

   cout << "operation -- size front end" << endl;
   cin >> op;
   while ( !cin.eof() ) {
        if ( op == "push" ) {
            cin >> val;
            s.push( val );
            cout << op << " " << val << "    -- ";
        }
        else if ( op == "pop" ) {
            s.pop();
            cout << op << "       -- ";
        }
        else {
            cerr << "Error input: " << op << endl;
            return 1;
        }
        cout << setw(3) << s.size() << setw(5) << s.top() << endl;
        cin >> op;
    }

    while ( !s.empty() )
        s.pop();
    cout << "End -- size of Stack is: " << s.size() << endl;

    return 0;
}



//

//  END OF FILE

//










