/*          FILE INFO
NAME:   	Tom Eisenbrandt
ZID:    	Z1771209
CLASS:  	CSCI 340
SECTION:	03
PROJECT:	07
DUE:    	April 6th 11:59PM
*/

#include <iostream>
#include <iomanip>
#include <algorithm>
#include <vector>

using namespace std ;

const int HEAP_SIZE = 50;

int PRINT_COUNT = 0 ;

/*
FUNCTION:   void heapify( vector < int >& v , int HEAP_SIZE , int r , bool( *compar )( int , int ) )
PARAMETERS: vector < int >& v , int HEAP_SIZE , int r , bool( *compar )( int , int )
RETURN:     None
PURPOSE:    Turns tree into heap
*/
void heapify( vector < int >& v , int HEAP_SIZE , int r , bool( *compar )( int , int ) ) {

	//r = root
	int right = ( 2*r+1 ) ;
	int left = ( 2*r ) ;
	int largest_value = 0 ;


	//  Compare root with left child
	if( ( left <= HEAP_SIZE ) && ( compar( v[ left ] , v[ r ] ) ) ) {
		largest_value = left ;
	}
	else{
		largest_value = r ;
	}

	//  Compare 'largest' with right child
	if( ( right <= HEAP_SIZE - 1 ) && ( compar( v[ right ] , v[ largest_value ] ) ) ) {
		largest_value = right ;
	}

	//  If largest is not the root
	if( largest_value != r ) {
		swap( v[ r ] , v[ largest_value ] ) ;
		//  heapify through recursion
		heapify( v , HEAP_SIZE , largest_value , compar ) ;
	}

}

/*
FUNCTION:   bool less_than( int e1 , int e2 )
PARAMETERS: int e1 , int e2
RETURN:     boolean
PURPOSE:    check if e1 is less than e2
*/
bool less_than( int e1 , int e2 ) {

	if( e1 < e2 ) {
		return true ;
	}
	else{
		return false ;
	}

}

/*
FUNCTION:   bool greater_than( int e1 , int e2 )
PARAMETERS: int e1 , int e2
RETURN:     boolean
PURPOSE:    Check if e1 is greater than e2
*/
bool greater_than( int e1 , int e2 ) {

	if( e1 > e2 ) {
		return true ;
	}
	else{
		return false ;
	}

}

/*
FUNCTION:   int extract_heap( vector < int >& v , int& HEAP_SIZE , bool ( *compar )( int , int ) )
PARAMETERS: vector < int >& v , int& HEAP_SIZE , bool ( *compar )( int , int )
RETURN:     integer
PURPOSE:    Extracts root of heap
*/
int extract_heap( vector < int >& v , int& HEAP_SIZE , bool ( *compar )( int , int ) ) {

	int root = v[ 1 ] ;

	if( !v.empty( ) ) {
		v[ 1 ] = v[ HEAP_SIZE ] ;   //  swap root and last value
		HEAP_SIZE-- ;   // reduce heap size by 1
	}

	heapify( v , HEAP_SIZE, 1 , compar ) ;	//  heapify resulting tree

	return root ;

}

/*
FUNCTION:   void build_heap( vector < int >& v , int HEAP_SIZE , bool( *compar )( int , int ) )
PARAMETERS: vector < int >& v , int HEAP_SIZE , bool( *compar )( int , int )
RETURN:     None
PURPOSE:    Create the heap
*/
void build_heap( vector < int >& v , int HEAP_SIZE , bool( *compar )( int , int ) ) {

	for( int i = HEAP_SIZE/2 ; i > 0 ; i-- ) {
		heapify( v , HEAP_SIZE , i , compar ) ; //  heapify the resulting tree
	}

}

/*
FUNCTION:   void heap_sort( vector <int >& v , int HEAP_SIZE , bool( *compar )( int , int ) )
PARAMETERS: vector <int >& v , int HEAP_SIZE , bool( *compar )( int , int )
RETURN:     None
PURPOSE:    Sort heap
*/
void heap_sort( vector <int >& v , int HEAP_SIZE , bool( *compar )( int , int ) ) {

	for( int i = HEAP_SIZE ; i > 1 ; i-- ) {
		v[ i ] = extract_heap( v , HEAP_SIZE , compar ) ;
	}

	if( PRINT_COUNT == 2 ) {
		//  Print in reverse order for min heap ascending order
		reverse( v.begin( )+1 , v.end( ) ) ;
	}

}

/*
FUNCTION:   void print_vector( vector < int >& v , int pos , int size )
PARAMETERS: vector < int >& v , int pos , int size
RETURN:     None
PURPOSE:    Print heap
*/
void print_vector( vector < int >& v , int pos , int size ) {

	PRINT_COUNT++;

	const int LINE_MAX = 8 ;
	const int SPACE_MAX = 5 ;
	int item_count = 0 ;

	for( int i = pos ; i < size + 1 ; i++ ) {

		if( item_count == LINE_MAX ) {
			item_count = 0 ;
			cout << "\n" ;
		}
		
	item_count++ ;
	cout << setw( SPACE_MAX ) << v[ i ] ;   //  Display output
	}

	cout << "\n\n" ;    //  Spacing

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char** argv) {
    // ------- creating input vector --------------
    vector<int> v;
    v.push_back(-1000000);    // first element is fake
    for (int i=1; i<=HEAP_SIZE; i++)
        v.push_back( i );
    random_shuffle( v.begin()+1, v.begin()+HEAP_SIZE+1 );

    cout << "\nCurrent input numbers: " << endl;
    print_vector( v, 1, HEAP_SIZE );

    // ------- testing min heap ------------------
    cout << "\nBuilding a min heap..." << endl;
    build_heap(v, HEAP_SIZE, less_than);
    cout << "Min heap: " << endl;
    print_vector( v, 1, HEAP_SIZE );
    heap_sort( v, HEAP_SIZE, less_than);
    cout << "Heap sort result (in ascending order): " << endl;
    print_vector( v, 1, HEAP_SIZE );

    // ------- testing max heap ------------------
    cout << "\nBuilding a max heap..." << endl;
    build_heap(v, HEAP_SIZE, greater_than);
    cout << "Max heap: " << endl;
    print_vector( v, 1, HEAP_SIZE );
    heap_sort( v, HEAP_SIZE, greater_than);
    cout << "Heap sort result (in descending order): " << endl;
    print_vector( v, 1, HEAP_SIZE );

    return 0;
}

/*
END OF FILE
*/

