/*
FILE INFO
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 340
SECTION:    03
PROJECT:    05
DUE DATE:   March 9th 2017 11:59 PM
FILENAME:   assignment5.cc
*/

#include <iostream>     	//  Input/Output streaming
#include <iomanip>      	//  Input/Output manipulation
#include <algorithm>    	//  Algorithms
#include <vector>       	//  Vectors
#include "assignment5.h"    //  Include header file

#include "assignment6.h"


using namespace std;        //  Exclude need for std::

const int MAX_SIZE = 40;    //  MAX_SIZE has a constant value of 40
const int MAX_COUNTY = 40;   //  MAX_COUNT has a constant value of 40
const int WIDTH = 5;        //  WIDTH has a constant value of 5
const int ROW_SIZE = 8;     //  ROW_SIZE has a constant value of 8

int mcounty = 0; 			//  mcount is a counter with global scope
int rcount = 0; 			//  rcount is a counter with global scope

void display( int d ) {
	
	if ( mcounty < MAX_COUNTY ) {
	cout << setw( WIDTH ) << d ;
	mcounty++ ;
	rcount++ ;
	
		if ( rcount == ROW_SIZE ) {
    	cout << endl ;
    	rcount = 0 ;
    	}
    	
	}
	
}

/*              PUBLIC
FUNCTION:       binTree::binTree()
PARAMETERS:     None
RETURNS:        None
PURPOSE:        Constructor of binTree class
*/
binTree::binTree( ) {
	root = nullptr ;    //  ititializes root to nullptr
}

/*              PUBLIC
FUNCTION:       void binTree::insert( int d )
PARAMETERS:     int d
RETURNS:        None
PURPOSE:        Constructor
*/
void binTree::insert( int d ) {
	insert( root , d ) ;
}

/*              PUBLIC
FUNCTION:       int binTree::height( ) const
PARAMETERS:     None
RETURNS:        Integer
PURPOSE:        Find height
*/
int binTree::height( ) const {
	return height( root ) ;
}

/*              PUBLIC
FUNCTION:       unsigned binTree::size( ) const
PARAMETERS:     None
RETURNS:        Unsigned
PURPOSE:        Find size
*/
unsigned binTree::size( ) const{
	return size( root ) ;
}

/*              PUBLIC
FUNCTION:       void binTree::inorder( void(*)( int ) )
PARAMETERS:     void(*)( int )
RETURNS:        None
PURPOSE:        LEFT - NODE - RIGHT
*/
void binTree::inorder( void(*p)( int ) ) {
	inorder( root , p ) ;
}

/*              PUBLIC
FUNCTION:       void binTree::preorder( void(*)( int ) )
PARAMETERS:     void(*)( int )
RETURNS:        None
PURPOSE:        NODE - LEFT - RIGHT
*/
void binTree::preorder( void(*p)( int ) ) {
	preorder( root , p ) ;
}

/*              PUBLIC
FUNCTION:       void binTree::postorder( void(*)( int ) )
PARAMETERS:     void(*)( int )
RETURNS:        None
PURPOSE:        LEFT - RIGHT - NODE
*/
void binTree::postorder( void(*p)( int ) ) {
	postorder( root , p ) ;
}

/////////////////////////////////////////////////////////////////////////////

/*              PRIVATE
FUNCTION:       void binTree::insert( Node*& r , int x )
PARAMETERS:     Node*& r , int x
RETURNS:        None
PURPOSE:        Creates a new node
*/
void binTree::insert( Node*& r , int x ) {
	if( r == nullptr ) {
		r = new Node( x ) ;
	}
	else{
// Compare tree height
		if( height( r -> right) < height( r -> left ) ) {
// Value compared and inserted into left or right tree		
		insert( r -> right , x ) ;
		}
		else{
		insert( r -> left , x ) ;
		}
	}
}

/*              PRIVATE
FUNCTION:       int binTree::height( Node* r ) const
PARAMETERS:     Node* r
RETURNS:        Integer
PURPOSE:        Finds height of tree via recusion
*/
int binTree::height( Node* r ) const {
	if( r == nullptr )
		return 0 ;
	return 1 + max( height( r -> left ) , height( r -> right ) ) ;
}

/*              PRIVATE
FUNCTION:       unsigned binTree::size( Node* n ) const
PARAMETERS:     Node* n
RETURNS:        Unsigned
PURPOSE:       	Find the tree's size
*/
unsigned binTree::size( Node* r ) const {
	if( r == nullptr )
		return 0 ;
	else
		return( size( r -> left) + size( r -> right ) + 1 ) ;
}

/*              PRIVATE
FUNCTION:       void binTree::inorder( Node* r , void( *p )( int ) )
PARAMETERS:     Node* r , void( *p )( int )
RETURNS:        None
PURPOSE:        Sorts as Left tree - Node - Right tree
*/
void binTree::inorder( Node* r , void( *p )( int ) ) {
	if( r != nullptr ) {
		inorder( r -> left , p ) ;
		p( r -> data ) ;
		inorder( r -> right , p ) ;
	}
}

/*              PRIVATE
FUNCTION:       void binTree::preorder( Node* r , void( *p )( int ) )
PARAMETERS:     Node* r , void( *x )( int )
RETURNS:        None
PURPOSE:        Sorts as Node - Left - Right
*/
void binTree::preorder( Node* r , void( *p )( int ) ) {
	if( r != nullptr ) {
		p( r -> data ) ;
		preorder( r -> left , p ) ;
		preorder( r -> right , p ) ;
	}
}

/*              PRIVATE
FUNCTION:       void binTree::postorder( Node* r , void( *p )( int ) )
PARAMETERS:     Node* r , void( *p )( int )
RETURNS:        None
PURPOSE:        Sorts as Left - Right -  Node
*/
void binTree::postorder( Node* r , void( *p )( int ) ) {
	if( r != nullptr ) {
		postorder( r -> left , p ) ;
		postorder( r -> right , p ) ;
		p( r -> data ) ;
	}
}

///////////    ASSIGNMENT 6 EDIT   /////////////////
/*

#define BINTREE_MAIN
#ifdef BINTREE_MAIN
int main() {
    vector<int> v(MAX_SIZE);
    for (int i=1; i<MAX_SIZE; i++)
        v[i] = i;
    random_shuffle( v.begin(), v.end() );

    binTree bt;
    vector<int>::iterator it;
    for (it=v.begin(); it!=v.end(); it++)
        bt.insert( *it );

    cout << "Height: " << bt.height() << endl;
    cout << "Size: " << bt.size() << endl;
    cout << "In order traverse (displaying first " << MAX_COUNTY << " numbers): " << endl;
    mcount = rcount = 0;
    bt.inorder( display );
    cout << "\n\nPre order traverse (displaying first " << MAX_COUNTY << " numbers): " << endl;
    mcount = rcount = 0;
    bt.preorder( display );
    cout << "\n\nPost order traverse (displaying first " << MAX_COUNTY << " numbers): " << endl;
    mcount = rcount = 0;
    bt.postorder( display );

    cout << endl;
    return 0;
}

#endif

///////    ASSIGNMENT 6 EDIT   /////////////////
*/

/////////////////////////////////////////
//          END OF FILE                //
/////////////////////////////////////////
