/*
FILE INFO
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 340
SECTION:    03
PROJECT:    06
DUE:        March 27th 11:59PM
FILENAME:   assignment6.h
*/

#ifndef ASSIGNMENT6
#define ASSIGNMENT6

#include "assignment5.h"

//#include "assignment5.cc"

class BST : public binTree {
	
	friend class Node ;
	friend class binTree ;
	
    public:
    	//  Constructor(derived) - base class constructor
        BST( ) : binTree( ) { } ;
        //  Insert to tree
        void insert( int );
        //  Search within tree
        bool search( int );
        //  Remove from tree
        bool remove( int );
        //  Sum of values between range ( lower, upper )
        int sumOfRange(int lower, const int upper);
        
    private:
    	//  Private version
        void insert( Node*&, int );
        //  Private version
        bool search( Node*&, int );
        //  Private Version
        bool remove( Node*&, int );
        //  Private version
        int sumOfRange(Node*& n, const int lower, const int upper);
};

#endif

/*

END OF FILE

*/
