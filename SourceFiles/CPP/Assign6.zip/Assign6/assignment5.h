/*
FILE INFO
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 340
SECTION:    03
PROJECT:    05
DUE DATE:   March 9th 2017 11:59 PM
FILENAME:   assignment5.h
*/

#ifndef ASSIGNMENT5     //  Header gaurds
#define ASSIGNMENT5     //  Header gaurds

//class binTree;      //  Declare binTree class
//class BST;          //  Declare BST class

class Node {

	friend class binTree ;  //  Class Node is a friend of class binTree
	///////    ASSIGNMENT 6 EDIT   ///////////////
	friend class BST ;  //  Class node is a friend of class BST

	private:
	int data ;  	//  Each node assigned data storage
	Node *left ;    //  Points to left node
	Node *right ;   //  Points to right node

	public:
	Node( int& d, Node* LEFT = 0, Node* RIGHT = 0 ) { 		//  Creates new nodes and initializes their values
		data = d ;
		left = LEFT ;
		right = RIGHT ;
	}

} ;


class binTree {
	
	///////    ASSIGNMENT 6 EDIT   ///////////////
	friend class Node ;
	friend class BST ;
	
    public:
        binTree();
        virtual void insert( int );
        int height() const;
        unsigned size() const;
        void inorder( void(*)(int) );
        void preorder( void(*)(int) );
        void postorder( void(*)(int) );

    protected:
        Node* root;

    private:
        void insert( Node*&, int );
        int height( Node* ) const;
        unsigned size( Node* ) const;
	void inorder( Node*, void(*)(int) );
	void preorder( Node*, void(*)(int) );
	void postorder( Node*, void(*)(int) );
};

#endif





/////////////////////////////////////////
//          END OF FILE                //
/////////////////////////////////////////
