/*
FILE INFO
NAME:       Tom Eisenbrandt
ZID:        Z1771209
CLASS:      CSCI 340
SECTION:    03
PROJECT:    06
DUE:        March 27th 11:59PM
FILENAME:   assignment6.cc
*/

#include <iostream>

#include "assignment6.h"

#include "assignment5.h"

using namespace std ;


/*
FUNCTION:
PUBLIC - void BST::insert( int x )
PARAMETER(S):
int x
RETURN:
None
PURPOSE:
Calls private insert() to insert value of x into tree
*/
void BST::insert( int x ) {

	insert( root, x ) ;

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PRIVATE - void BST::insert( Node*& n, int x )
PARAMETER(S):
Node*& n, int x
RETURN:
None
PURPOSE:
Insert value of x into tree
*/
void BST::insert( Node*& n, int x ) {

	if ( n == NULL ) {
	n = new Node( x ) ;
	}

	else if( x < n -> data ) {
	insert( n -> left, x ) ;
	}

	else if( x > n -> data ) {
	insert( n -> right, x ) ;
	}

	else{
	cout << "\n\nERROR\n\n" ;
	}

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PUBLIC - bool BST::search( int x )
PARAMETER(S):
int x
RETURN:
boolean
true - if value is found
false - if value is not found
PURPOSE:
Passes x to private version to search tree for its value
*/
bool BST::search( int x ) {

	return search( root, x ) ;

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PRIVATE - bool BST::search( Node*& n , int x )
PARAMETER(S):
Node*& n , int x
RETURN:
boolean
true - if value is found
false - if value is not found
PURPOSE:
Checks for value of x within tree
*/
bool BST::search( Node*& n , int x ) {

	if ( n == NULL ) {
	return false ;
	}

	else if( n -> data == x ) {
	return true ;
	}

	else if( n -> data > x ) {
	return( search( n -> left, x ) ) ;
	}

	else if( n -> data < x ) {
	return( search( n -> right, x ) ) ;
	}

	else{
	return false ;
	}

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PUBLIC - bool BST::remove( int x )
PARAMETER(S):
int x
RETURN:
boolean
PURPOSE:
Calls private remove() to see if x's value may be removed
*/
bool BST::remove( int x ) {
	
	return remove( root, x ) ;

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PRIVATE - bool BST::remove( Node*& n , int x )
PARAMETER(S):
Node*& n , int x
RETURN:
boolean
PURPOSE:
Removes value of x from binary search tree
*/
bool BST::remove( Node*& n , int x ) {

	Node* temp = n ;

	if( n == NULL ) {
	return false ;
	}

	if( n -> data > x ) {
	return remove( n -> left, x ) ;
	}

	if( n -> data < x ) {
	return remove( n -> right, x ) ;
	}

	if( n -> right != NULL && n -> left != NULL ) {
	temp = n -> left ;

		while( temp -> right != NULL ) {
		temp = temp -> right ;
		}

	n -> data = temp -> data ;
	return remove( n -> left, temp -> data ) ;
	}

	if( n -> right == NULL ) {
	n = n -> left ;
	}

	else if( n -> left == NULL ){
	n = n -> right ;
	}

	else{
	temp = n -> left ;

		while( temp -> right != NULL ) {
		temp = temp -> right ;
		}

	temp -> right = n -> right ;
	temp = n ;
	n = n -> left ;
	delete temp ;
	}

	return true ;

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PUBLIC - int BST::sumOfRange( int lower, const int upper )
PARAMETER(S):
int lower, const int upper
RETURN:
integer
PURPOSE:
Finds the sum of the range
*/
int BST::sumOfRange( int lower, const int upper ) {

return sumOfRange( root, lower, upper ) ;

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*
FUNCTION:
PRIVATE - int BST::sumOfRange( Node*& n, const int lower, const int upper )
PARAMETER(S):
Node*& n, const int lower, const int upper
RETURN:
integer
PURPOSE:
Finds the sum of the range
*/
int BST::sumOfRange( Node*& n, const int lower, const int upper ) {

int TheSum = 0 ;

TheSum = upper - lower ;

return TheSum ;

}

//  ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   //

/*

END OF FILE

*/
