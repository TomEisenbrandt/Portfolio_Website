﻿namespace Assign6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MatrixInputGroup = new System.Windows.Forms.GroupBox();
            this.InputA12 = new System.Windows.Forms.TextBox();
            this.InputA11 = new System.Windows.Forms.TextBox();
            this.InputB33 = new System.Windows.Forms.TextBox();
            this.InputB32 = new System.Windows.Forms.TextBox();
            this.InputB23 = new System.Windows.Forms.TextBox();
            this.InputB22 = new System.Windows.Forms.TextBox();
            this.InputB13 = new System.Windows.Forms.TextBox();
            this.InputB12 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.InputB31 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.InputB21 = new System.Windows.Forms.TextBox();
            this.InputB11 = new System.Windows.Forms.TextBox();
            this.InputA33 = new System.Windows.Forms.TextBox();
            this.InputA23 = new System.Windows.Forms.TextBox();
            this.InputA13 = new System.Windows.Forms.TextBox();
            this.InputA21 = new System.Windows.Forms.TextBox();
            this.InputA31 = new System.Windows.Forms.TextBox();
            this.InputA32 = new System.Windows.Forms.TextBox();
            this.InputA22 = new System.Windows.Forms.TextBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.RREFButton = new System.Windows.Forms.Button();
            this.ButtonGroup = new System.Windows.Forms.GroupBox();
            this.RandomButton1 = new System.Windows.Forms.Button();
            this.RandomButton0 = new System.Windows.Forms.Button();
            this.RandomButton00 = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.OutputBox = new System.Windows.Forms.ListView();
            this.MatrixOutputGroup = new System.Windows.Forms.GroupBox();
            this.OutputB33 = new System.Windows.Forms.TextBox();
            this.OutputB32 = new System.Windows.Forms.TextBox();
            this.OutputB23 = new System.Windows.Forms.TextBox();
            this.OutputB13 = new System.Windows.Forms.TextBox();
            this.OutputB22 = new System.Windows.Forms.TextBox();
            this.OutputB12 = new System.Windows.Forms.TextBox();
            this.OutputB31 = new System.Windows.Forms.TextBox();
            this.OutputB21 = new System.Windows.Forms.TextBox();
            this.OutputB11 = new System.Windows.Forms.TextBox();
            this.OutputA33 = new System.Windows.Forms.TextBox();
            this.OutputA32 = new System.Windows.Forms.TextBox();
            this.OutputA31 = new System.Windows.Forms.TextBox();
            this.OutputA23 = new System.Windows.Forms.TextBox();
            this.OutputA22 = new System.Windows.Forms.TextBox();
            this.OutputA21 = new System.Windows.Forms.TextBox();
            this.OutputA13 = new System.Windows.Forms.TextBox();
            this.OutputA12 = new System.Windows.Forms.TextBox();
            this.OutputA11 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.MatrixInputGroup.SuspendLayout();
            this.ButtonGroup.SuspendLayout();
            this.MatrixOutputGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // MatrixInputGroup
            // 
            this.MatrixInputGroup.Controls.Add(this.InputA12);
            this.MatrixInputGroup.Controls.Add(this.InputA11);
            this.MatrixInputGroup.Controls.Add(this.InputB33);
            this.MatrixInputGroup.Controls.Add(this.InputB32);
            this.MatrixInputGroup.Controls.Add(this.InputB23);
            this.MatrixInputGroup.Controls.Add(this.InputB22);
            this.MatrixInputGroup.Controls.Add(this.InputB13);
            this.MatrixInputGroup.Controls.Add(this.InputB12);
            this.MatrixInputGroup.Controls.Add(this.label2);
            this.MatrixInputGroup.Controls.Add(this.InputB31);
            this.MatrixInputGroup.Controls.Add(this.label1);
            this.MatrixInputGroup.Controls.Add(this.InputB21);
            this.MatrixInputGroup.Controls.Add(this.InputB11);
            this.MatrixInputGroup.Controls.Add(this.InputA33);
            this.MatrixInputGroup.Controls.Add(this.InputA23);
            this.MatrixInputGroup.Controls.Add(this.InputA13);
            this.MatrixInputGroup.Controls.Add(this.InputA21);
            this.MatrixInputGroup.Controls.Add(this.InputA31);
            this.MatrixInputGroup.Controls.Add(this.InputA32);
            this.MatrixInputGroup.Controls.Add(this.InputA22);
            this.MatrixInputGroup.Location = new System.Drawing.Point(20, 20);
            this.MatrixInputGroup.Name = "MatrixInputGroup";
            this.MatrixInputGroup.Size = new System.Drawing.Size(325, 150);
            this.MatrixInputGroup.TabIndex = 0;
            this.MatrixInputGroup.TabStop = false;
            this.MatrixInputGroup.Text = "Matrix Input";
            // 
            // InputA12
            // 
            this.InputA12.Location = new System.Drawing.Point(52, 71);
            this.InputA12.Name = "InputA12";
            this.InputA12.Size = new System.Drawing.Size(40, 20);
            this.InputA12.TabIndex = 1;
            this.InputA12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA11
            // 
            this.InputA11.Location = new System.Drawing.Point(6, 71);
            this.InputA11.Name = "InputA11";
            this.InputA11.Size = new System.Drawing.Size(40, 20);
            this.InputA11.TabIndex = 0;
            this.InputA11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB33
            // 
            this.InputB33.Location = new System.Drawing.Point(262, 124);
            this.InputB33.Name = "InputB33";
            this.InputB33.Size = new System.Drawing.Size(40, 20);
            this.InputB33.TabIndex = 17;
            this.InputB33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB32
            // 
            this.InputB32.Location = new System.Drawing.Point(216, 123);
            this.InputB32.Name = "InputB32";
            this.InputB32.Size = new System.Drawing.Size(40, 20);
            this.InputB32.TabIndex = 16;
            this.InputB32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB23
            // 
            this.InputB23.Location = new System.Drawing.Point(262, 97);
            this.InputB23.Name = "InputB23";
            this.InputB23.Size = new System.Drawing.Size(40, 20);
            this.InputB23.TabIndex = 14;
            this.InputB23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB22
            // 
            this.InputB22.Location = new System.Drawing.Point(216, 97);
            this.InputB22.Name = "InputB22";
            this.InputB22.Size = new System.Drawing.Size(40, 20);
            this.InputB22.TabIndex = 13;
            this.InputB22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB13
            // 
            this.InputB13.Location = new System.Drawing.Point(262, 71);
            this.InputB13.Name = "InputB13";
            this.InputB13.Size = new System.Drawing.Size(40, 20);
            this.InputB13.TabIndex = 11;
            this.InputB13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB12
            // 
            this.InputB12.Location = new System.Drawing.Point(216, 71);
            this.InputB12.Name = "InputB12";
            this.InputB12.Size = new System.Drawing.Size(40, 20);
            this.InputB12.TabIndex = 10;
            this.InputB12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(213, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Matrix B";
            // 
            // InputB31
            // 
            this.InputB31.Location = new System.Drawing.Point(170, 124);
            this.InputB31.Name = "InputB31";
            this.InputB31.Size = new System.Drawing.Size(40, 20);
            this.InputB31.TabIndex = 15;
            this.InputB31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Matrix A";
            // 
            // InputB21
            // 
            this.InputB21.Location = new System.Drawing.Point(170, 98);
            this.InputB21.Name = "InputB21";
            this.InputB21.Size = new System.Drawing.Size(40, 20);
            this.InputB21.TabIndex = 12;
            this.InputB21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputB11
            // 
            this.InputB11.Location = new System.Drawing.Point(170, 72);
            this.InputB11.Name = "InputB11";
            this.InputB11.Size = new System.Drawing.Size(40, 20);
            this.InputB11.TabIndex = 9;
            this.InputB11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA33
            // 
            this.InputA33.Location = new System.Drawing.Point(98, 124);
            this.InputA33.Name = "InputA33";
            this.InputA33.Size = new System.Drawing.Size(40, 20);
            this.InputA33.TabIndex = 8;
            this.InputA33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA23
            // 
            this.InputA23.Location = new System.Drawing.Point(98, 98);
            this.InputA23.Name = "InputA23";
            this.InputA23.Size = new System.Drawing.Size(40, 20);
            this.InputA23.TabIndex = 5;
            this.InputA23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA13
            // 
            this.InputA13.Location = new System.Drawing.Point(98, 72);
            this.InputA13.Name = "InputA13";
            this.InputA13.Size = new System.Drawing.Size(40, 20);
            this.InputA13.TabIndex = 2;
            this.InputA13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA21
            // 
            this.InputA21.Location = new System.Drawing.Point(6, 98);
            this.InputA21.Name = "InputA21";
            this.InputA21.Size = new System.Drawing.Size(40, 20);
            this.InputA21.TabIndex = 3;
            this.InputA21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA31
            // 
            this.InputA31.Location = new System.Drawing.Point(6, 124);
            this.InputA31.Name = "InputA31";
            this.InputA31.Size = new System.Drawing.Size(40, 20);
            this.InputA31.TabIndex = 6;
            this.InputA31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA32
            // 
            this.InputA32.Location = new System.Drawing.Point(52, 124);
            this.InputA32.Name = "InputA32";
            this.InputA32.Size = new System.Drawing.Size(40, 20);
            this.InputA32.TabIndex = 7;
            this.InputA32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InputA22
            // 
            this.InputA22.Location = new System.Drawing.Point(52, 98);
            this.InputA22.Name = "InputA22";
            this.InputA22.Size = new System.Drawing.Size(40, 20);
            this.InputA22.TabIndex = 4;
            this.InputA22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(158, 132);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 40);
            this.ExitButton.TabIndex = 5;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // RREFButton
            // 
            this.RREFButton.Location = new System.Drawing.Point(52, 40);
            this.RREFButton.Name = "RREFButton";
            this.RREFButton.Size = new System.Drawing.Size(206, 40);
            this.RREFButton.TabIndex = 0;
            this.RREFButton.Text = "Compute \r\nAugmented RREF";
            this.RREFButton.UseVisualStyleBackColor = true;
            this.RREFButton.Click += new System.EventHandler(this.RREFButton_Click);
            // 
            // ButtonGroup
            // 
            this.ButtonGroup.Controls.Add(this.RandomButton1);
            this.ButtonGroup.Controls.Add(this.RandomButton0);
            this.ButtonGroup.Controls.Add(this.RandomButton00);
            this.ButtonGroup.Controls.Add(this.ClearButton);
            this.ButtonGroup.Controls.Add(this.RREFButton);
            this.ButtonGroup.Controls.Add(this.ExitButton);
            this.ButtonGroup.Location = new System.Drawing.Point(20, 434);
            this.ButtonGroup.Name = "ButtonGroup";
            this.ButtonGroup.Size = new System.Drawing.Size(325, 203);
            this.ButtonGroup.TabIndex = 3;
            this.ButtonGroup.TabStop = false;
            this.ButtonGroup.Text = "Buttons";
            // 
            // RandomButton1
            // 
            this.RandomButton1.Location = new System.Drawing.Point(6, 86);
            this.RandomButton1.Name = "RandomButton1";
            this.RandomButton1.Size = new System.Drawing.Size(100, 40);
            this.RandomButton1.TabIndex = 1;
            this.RandomButton1.Text = "Random \r\n(-1 to 1)";
            this.RandomButton1.UseVisualStyleBackColor = true;
            this.RandomButton1.Click += new System.EventHandler(this.RandomButton1_Click);
            // 
            // RandomButton0
            // 
            this.RandomButton0.Location = new System.Drawing.Point(110, 86);
            this.RandomButton0.Name = "RandomButton0";
            this.RandomButton0.Size = new System.Drawing.Size(100, 40);
            this.RandomButton0.TabIndex = 2;
            this.RandomButton0.Text = "Random\r\n(-9 to 9)";
            this.RandomButton0.UseVisualStyleBackColor = true;
            this.RandomButton0.Click += new System.EventHandler(this.RandomButton0_Click);
            // 
            // RandomButton00
            // 
            this.RandomButton00.Location = new System.Drawing.Point(214, 86);
            this.RandomButton00.Name = "RandomButton00";
            this.RandomButton00.Size = new System.Drawing.Size(100, 40);
            this.RandomButton00.TabIndex = 3;
            this.RandomButton00.Text = "Random \r\n(-99 to 99)";
            this.RandomButton00.UseVisualStyleBackColor = true;
            this.RandomButton00.Click += new System.EventHandler(this.RandomButton00_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(52, 132);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(100, 40);
            this.ClearButton.TabIndex = 4;
            this.ClearButton.Text = "Reset Values";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // OutputBox
            // 
            this.OutputBox.GridLines = true;
            this.OutputBox.Location = new System.Drawing.Point(351, 25);
            this.OutputBox.Name = "OutputBox";
            this.OutputBox.Size = new System.Drawing.Size(356, 612);
            this.OutputBox.TabIndex = 1;
            this.OutputBox.TileSize = new System.Drawing.Size(50, 30);
            this.OutputBox.UseCompatibleStateImageBehavior = false;
            this.OutputBox.View = System.Windows.Forms.View.List;
            // 
            // MatrixOutputGroup
            // 
            this.MatrixOutputGroup.Controls.Add(this.OutputB33);
            this.MatrixOutputGroup.Controls.Add(this.OutputB32);
            this.MatrixOutputGroup.Controls.Add(this.OutputB23);
            this.MatrixOutputGroup.Controls.Add(this.OutputB13);
            this.MatrixOutputGroup.Controls.Add(this.OutputB22);
            this.MatrixOutputGroup.Controls.Add(this.OutputB12);
            this.MatrixOutputGroup.Controls.Add(this.OutputB31);
            this.MatrixOutputGroup.Controls.Add(this.OutputB21);
            this.MatrixOutputGroup.Controls.Add(this.OutputB11);
            this.MatrixOutputGroup.Controls.Add(this.OutputA33);
            this.MatrixOutputGroup.Controls.Add(this.OutputA32);
            this.MatrixOutputGroup.Controls.Add(this.OutputA31);
            this.MatrixOutputGroup.Controls.Add(this.OutputA23);
            this.MatrixOutputGroup.Controls.Add(this.OutputA22);
            this.MatrixOutputGroup.Controls.Add(this.OutputA21);
            this.MatrixOutputGroup.Controls.Add(this.OutputA13);
            this.MatrixOutputGroup.Controls.Add(this.OutputA12);
            this.MatrixOutputGroup.Controls.Add(this.OutputA11);
            this.MatrixOutputGroup.Controls.Add(this.label4);
            this.MatrixOutputGroup.Controls.Add(this.label3);
            this.MatrixOutputGroup.Location = new System.Drawing.Point(20, 189);
            this.MatrixOutputGroup.Name = "MatrixOutputGroup";
            this.MatrixOutputGroup.Size = new System.Drawing.Size(325, 150);
            this.MatrixOutputGroup.TabIndex = 4;
            this.MatrixOutputGroup.TabStop = false;
            this.MatrixOutputGroup.Text = "Matrix Output";
            // 
            // OutputB33
            // 
            this.OutputB33.Location = new System.Drawing.Point(262, 104);
            this.OutputB33.Name = "OutputB33";
            this.OutputB33.ReadOnly = true;
            this.OutputB33.Size = new System.Drawing.Size(40, 20);
            this.OutputB33.TabIndex = 17;
            this.OutputB33.Text = "B33";
            this.OutputB33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB32
            // 
            this.OutputB32.Location = new System.Drawing.Point(216, 104);
            this.OutputB32.Name = "OutputB32";
            this.OutputB32.ReadOnly = true;
            this.OutputB32.Size = new System.Drawing.Size(40, 20);
            this.OutputB32.TabIndex = 16;
            this.OutputB32.Text = "B32";
            this.OutputB32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB23
            // 
            this.OutputB23.Location = new System.Drawing.Point(262, 78);
            this.OutputB23.Name = "OutputB23";
            this.OutputB23.ReadOnly = true;
            this.OutputB23.Size = new System.Drawing.Size(40, 20);
            this.OutputB23.TabIndex = 14;
            this.OutputB23.Text = "B23";
            this.OutputB23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB13
            // 
            this.OutputB13.Location = new System.Drawing.Point(262, 52);
            this.OutputB13.Name = "OutputB13";
            this.OutputB13.ReadOnly = true;
            this.OutputB13.Size = new System.Drawing.Size(40, 20);
            this.OutputB13.TabIndex = 11;
            this.OutputB13.Text = "B13";
            this.OutputB13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB22
            // 
            this.OutputB22.Location = new System.Drawing.Point(216, 78);
            this.OutputB22.Name = "OutputB22";
            this.OutputB22.ReadOnly = true;
            this.OutputB22.Size = new System.Drawing.Size(40, 20);
            this.OutputB22.TabIndex = 13;
            this.OutputB22.Text = "B22";
            this.OutputB22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB12
            // 
            this.OutputB12.Location = new System.Drawing.Point(216, 52);
            this.OutputB12.Name = "OutputB12";
            this.OutputB12.ReadOnly = true;
            this.OutputB12.Size = new System.Drawing.Size(40, 20);
            this.OutputB12.TabIndex = 10;
            this.OutputB12.Text = "B12";
            this.OutputB12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB31
            // 
            this.OutputB31.Location = new System.Drawing.Point(170, 104);
            this.OutputB31.Name = "OutputB31";
            this.OutputB31.ReadOnly = true;
            this.OutputB31.Size = new System.Drawing.Size(40, 20);
            this.OutputB31.TabIndex = 15;
            this.OutputB31.Text = "B31";
            this.OutputB31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB21
            // 
            this.OutputB21.Location = new System.Drawing.Point(170, 78);
            this.OutputB21.Name = "OutputB21";
            this.OutputB21.ReadOnly = true;
            this.OutputB21.Size = new System.Drawing.Size(40, 20);
            this.OutputB21.TabIndex = 12;
            this.OutputB21.Text = "B21";
            this.OutputB21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputB11
            // 
            this.OutputB11.Location = new System.Drawing.Point(170, 52);
            this.OutputB11.Name = "OutputB11";
            this.OutputB11.ReadOnly = true;
            this.OutputB11.Size = new System.Drawing.Size(40, 20);
            this.OutputB11.TabIndex = 9;
            this.OutputB11.Text = "B11";
            this.OutputB11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA33
            // 
            this.OutputA33.Location = new System.Drawing.Point(98, 104);
            this.OutputA33.Name = "OutputA33";
            this.OutputA33.ReadOnly = true;
            this.OutputA33.Size = new System.Drawing.Size(40, 20);
            this.OutputA33.TabIndex = 8;
            this.OutputA33.Text = "A33";
            this.OutputA33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA32
            // 
            this.OutputA32.Location = new System.Drawing.Point(52, 104);
            this.OutputA32.Name = "OutputA32";
            this.OutputA32.ReadOnly = true;
            this.OutputA32.Size = new System.Drawing.Size(40, 20);
            this.OutputA32.TabIndex = 7;
            this.OutputA32.Text = "A32";
            this.OutputA32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA31
            // 
            this.OutputA31.Location = new System.Drawing.Point(6, 104);
            this.OutputA31.Name = "OutputA31";
            this.OutputA31.ReadOnly = true;
            this.OutputA31.Size = new System.Drawing.Size(40, 20);
            this.OutputA31.TabIndex = 6;
            this.OutputA31.Text = "A31";
            this.OutputA31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA23
            // 
            this.OutputA23.Location = new System.Drawing.Point(98, 78);
            this.OutputA23.Name = "OutputA23";
            this.OutputA23.ReadOnly = true;
            this.OutputA23.Size = new System.Drawing.Size(40, 20);
            this.OutputA23.TabIndex = 5;
            this.OutputA23.Text = "A23";
            this.OutputA23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA22
            // 
            this.OutputA22.Location = new System.Drawing.Point(52, 78);
            this.OutputA22.Name = "OutputA22";
            this.OutputA22.ReadOnly = true;
            this.OutputA22.Size = new System.Drawing.Size(40, 20);
            this.OutputA22.TabIndex = 4;
            this.OutputA22.Text = "A22";
            this.OutputA22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA21
            // 
            this.OutputA21.Location = new System.Drawing.Point(6, 78);
            this.OutputA21.Name = "OutputA21";
            this.OutputA21.ReadOnly = true;
            this.OutputA21.Size = new System.Drawing.Size(40, 20);
            this.OutputA21.TabIndex = 3;
            this.OutputA21.Text = "A21";
            this.OutputA21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA13
            // 
            this.OutputA13.Location = new System.Drawing.Point(98, 52);
            this.OutputA13.Name = "OutputA13";
            this.OutputA13.ReadOnly = true;
            this.OutputA13.Size = new System.Drawing.Size(40, 20);
            this.OutputA13.TabIndex = 2;
            this.OutputA13.Text = "A13";
            this.OutputA13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA12
            // 
            this.OutputA12.Location = new System.Drawing.Point(52, 52);
            this.OutputA12.Name = "OutputA12";
            this.OutputA12.ReadOnly = true;
            this.OutputA12.Size = new System.Drawing.Size(40, 20);
            this.OutputA12.TabIndex = 1;
            this.OutputA12.Text = "A12";
            this.OutputA12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OutputA11
            // 
            this.OutputA11.Location = new System.Drawing.Point(6, 52);
            this.OutputA11.Name = "OutputA11";
            this.OutputA11.ReadOnly = true;
            this.OutputA11.Size = new System.Drawing.Size(40, 20);
            this.OutputA11.TabIndex = 0;
            this.OutputA11.Text = "A11";
            this.OutputA11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(211, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Matrix B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Matrix A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(348, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Calculation Log";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox1.Location = new System.Drawing.Point(20, 346);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(325, 82);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "This program calculates the \nReduced Row Echelon Form (RREF) \nof the Augmented Ma" +
    "trix A and B.\n\nAny null input will used as zero.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 649);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.MatrixOutputGroup);
            this.Controls.Add(this.OutputBox);
            this.Controls.Add(this.ButtonGroup);
            this.Controls.Add(this.MatrixInputGroup);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MatrixInputGroup.ResumeLayout(false);
            this.MatrixInputGroup.PerformLayout();
            this.ButtonGroup.ResumeLayout(false);
            this.MatrixOutputGroup.ResumeLayout(false);
            this.MatrixOutputGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox MatrixInputGroup;
        private System.Windows.Forms.TextBox InputA33;
        private System.Windows.Forms.TextBox InputA23;
        private System.Windows.Forms.TextBox InputA13;
        private System.Windows.Forms.TextBox InputA32;
        private System.Windows.Forms.TextBox InputA22;
        private System.Windows.Forms.TextBox InputA12;
        private System.Windows.Forms.TextBox InputA31;
        private System.Windows.Forms.TextBox InputA21;
        private System.Windows.Forms.TextBox InputA11;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button RREFButton;
        private System.Windows.Forms.GroupBox ButtonGroup;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.TextBox InputB31;
        private System.Windows.Forms.TextBox InputB21;
        private System.Windows.Forms.TextBox InputB11;
        private System.Windows.Forms.ListView OutputBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox InputB33;
        private System.Windows.Forms.TextBox InputB32;
        private System.Windows.Forms.TextBox InputB23;
        private System.Windows.Forms.TextBox InputB22;
        private System.Windows.Forms.TextBox InputB13;
        private System.Windows.Forms.TextBox InputB12;
        private System.Windows.Forms.GroupBox MatrixOutputGroup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox OutputA11;
        private System.Windows.Forms.TextBox OutputB12;
        private System.Windows.Forms.TextBox OutputB31;
        private System.Windows.Forms.TextBox OutputB21;
        private System.Windows.Forms.TextBox OutputB11;
        private System.Windows.Forms.TextBox OutputA33;
        private System.Windows.Forms.TextBox OutputA32;
        private System.Windows.Forms.TextBox OutputA31;
        private System.Windows.Forms.TextBox OutputA23;
        private System.Windows.Forms.TextBox OutputA22;
        private System.Windows.Forms.TextBox OutputA21;
        private System.Windows.Forms.TextBox OutputA13;
        private System.Windows.Forms.TextBox OutputA12;
        private System.Windows.Forms.TextBox OutputB22;
        private System.Windows.Forms.TextBox OutputB33;
        private System.Windows.Forms.TextBox OutputB32;
        private System.Windows.Forms.TextBox OutputB23;
        private System.Windows.Forms.TextBox OutputB13;
        private System.Windows.Forms.Button RandomButton00;
        private System.Windows.Forms.Button RandomButton0;
        private System.Windows.Forms.Button RandomButton1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

